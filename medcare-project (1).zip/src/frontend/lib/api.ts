// Frontend API client - all fetch helpers live here

export interface Doctor {
  id: string
  name: string
  specialty: string
  subSpecialty: string | null
  bio: string | null
  image: string | null
  rating: number
  reviews: number
  experience: number
  fee: number
  available: boolean
  hospital: string | null
  languages: string | null
  location: string | null
}

export interface Appointment {
  id: string
  doctorId: string
  doctor: Doctor
  patientName: string
  patientEmail: string
  patientPhone: string | null
  date: string
  time: string
  type: string
  status: string
  reason: string | null
  notes: string | null
  createdAt: string
}

export interface MedicalRecord {
  id: string
  patientName: string
  title: string
  type: string
  date: string
  doctorName: string | null
  description: string
}

export interface Medication {
  id: string
  patientName: string
  name: string
  dosage: string
  frequency: string
  startDate: string
  endDate: string | null
  notes: string | null
  active: boolean
}

export interface HealthMetric {
  id: string
  patientName: string
  type: string
  value: string
  unit: string
  recordedAt: string
  notes: string | null
}

export interface Article {
  id: string
  title: string
  category: string
  excerpt: string
  content: string
  author: string
  readTime: number
  createdAt: string
}

export interface ChatMessage {
  id: string
  roomId: string
  sender: string
  senderName: string
  content: string
  type: string
  timestamp?: string
}

async function apiFetch<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  })
  if (!res.ok) {
    const data = await res.json().catch(() => ({ error: 'Request failed' }))
    throw new Error(data.error || `HTTP ${res.status}`)
  }
  return res.json()
}

// Doctors
export const doctorsApi = {
  list: (params?: { specialty?: string; search?: string; available?: boolean }) => {
    const query = new URLSearchParams()
    if (params?.specialty) query.set('specialty', params.specialty)
    if (params?.search) query.set('search', params.search)
    if (params?.available) query.set('available', 'true')
    const qs = query.toString()
    return apiFetch<{ doctors: Doctor[]; specialties: string[] }>(
      `/api/doctors${qs ? `?${qs}` : ''}`
    )
  },
}

// Appointments
export const appointmentsApi = {
  list: () => apiFetch<{ appointments: Appointment[] }>('/api/appointments'),
  create: (data: {
    doctorId: string
    patientName: string
    patientEmail: string
    patientPhone?: string
    date: string
    time: string
    type?: string
    reason?: string
  }) =>
    apiFetch<{ appointment: Appointment }>('/api/appointments', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  updateStatus: (id: string, status: string) =>
    apiFetch<{ appointment: Appointment }>('/api/appointments', {
      method: 'PATCH',
      body: JSON.stringify({ id, status }),
    }),
  cancel: (id: string) =>
    apiFetch<{ success: boolean }>(`/api/appointments?id=${id}`, {
      method: 'DELETE',
    }),
}

// Records
export const recordsApi = {
  list: () => apiFetch<{ records: MedicalRecord[] }>('/api/records'),
  create: (data: {
    patientName?: string
    title: string
    type: string
    date: string
    doctorName?: string
    description: string
  }) =>
    apiFetch<{ record: MedicalRecord }>('/api/records', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  delete: (id: string) =>
    apiFetch<{ success: boolean }>(`/api/records?id=${id}`, {
      method: 'DELETE',
    }),
}

// Medications
export const medicationsApi = {
  list: () => apiFetch<{ medications: Medication[] }>('/api/medications'),
  create: (data: {
    patientName?: string
    name: string
    dosage: string
    frequency: string
    startDate: string
    endDate?: string
    notes?: string
  }) =>
    apiFetch<{ medication: Medication }>('/api/medications', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  toggle: (id: string, active: boolean) =>
    apiFetch<{ medication: Medication }>('/api/medications', {
      method: 'PATCH',
      body: JSON.stringify({ id, active }),
    }),
  delete: (id: string) =>
    apiFetch<{ success: boolean }>(`/api/medications?id=${id}`, {
      method: 'DELETE',
    }),
}

// Metrics
export const metricsApi = {
  list: () => apiFetch<{ metrics: HealthMetric[] }>('/api/metrics'),
  create: (data: {
    patientName?: string
    type: string
    value: string
    unit: string
    recordedAt?: string
    notes?: string
  }) =>
    apiFetch<{ metric: HealthMetric }>('/api/metrics', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
}

// Articles
export const articlesApi = {
  list: (category?: string) => {
    const query = new URLSearchParams()
    if (category && category !== 'all') query.set('category', category)
    const qs = query.toString()
    return apiFetch<{ articles: Article[]; categories: string[] }>(
      `/api/articles${qs ? `?${qs}` : ''}`
    )
  },
}

// Symptom Checker
export const symptomCheckerApi = {
  analyze: (message: string, history: Array<{ role: string; content: string }>) =>
    apiFetch<{ response: string; message: string }>('/api/symptom-checker', {
      method: 'POST',
      body: JSON.stringify({ message, history }),
    }),
}

// Chat history (telemedicine fallback)
export const chatApi = {
  list: (roomId: string) =>
    apiFetch<{ messages: ChatMessage[] }>(`/api/chat?roomId=${roomId}`),
}
