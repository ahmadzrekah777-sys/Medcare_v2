import { create } from 'zustand'

export type ViewTab =
  | 'dashboard'
  | 'doctors'
  | 'appointments'
  | 'symptom-checker'
  | 'telemedicine'
  | 'records'
  | 'metrics'
  | 'medications'
  | 'articles'

interface AppState {
  activeTab: ViewTab
  setActiveTab: (tab: ViewTab) => void
  sidebarOpen: boolean
  setSidebarOpen: (open: boolean) => void
  // For booking flow: select a doctor then jump to appointments
  selectedDoctorId: string | null
  setSelectedDoctorId: (id: string | null) => void
}

export const useAppStore = create<AppState>((set) => ({
  activeTab: 'dashboard',
  setActiveTab: (tab) => set({ activeTab: tab }),
  sidebarOpen: false,
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  selectedDoctorId: null,
  setSelectedDoctorId: (id) => set({ selectedDoctorId: id }),
}))
