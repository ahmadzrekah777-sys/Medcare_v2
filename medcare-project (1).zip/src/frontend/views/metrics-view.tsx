'use client'

import { useEffect, useMemo, useState } from 'react'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import {
  Activity,
  Plus,
  Heart,
  Droplet,
  Scale,
  TrendingUp,
  TrendingDown,
  Calendar,
  Minus,
  Loader2,
  ClipboardList,
} from 'lucide-react'
import { toast } from 'sonner'
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
} from 'recharts'
import { metricsApi, type HealthMetric } from '@/frontend/lib/api'

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

type MetricType = 'ضغط الدم' | 'معدل ضربات القلب' | 'السكر' | 'الوزن'

interface MetricMeta {
  type: MetricType
  label: string
  unit: string
  icon: typeof Heart
  iconColor: string
  chartColor: string
  chartGradient: string
}

const METRIC_META: MetricMeta[] = [
  {
    type: 'ضغط الدم',
    label: 'ضغط الدم',
    unit: 'mmHg',
    icon: Heart,
    iconColor: 'text-emerald-600 bg-emerald-500/10',
    chartColor: '#10b981',
    chartGradient: 'emeraldGrad',
  },
  {
    type: 'معدل ضربات القلب',
    label: 'معدل ضربات القلب',
    unit: 'bpm',
    icon: Activity,
    iconColor: 'text-teal-600 bg-teal-500/10',
    chartColor: '#14b8a6',
    chartGradient: 'tealGrad',
  },
  {
    type: 'السكر',
    label: 'السكر',
    unit: 'mg/dL',
    icon: Droplet,
    iconColor: 'text-cyan-600 bg-cyan-500/10',
    chartColor: '#06b6d4',
    chartGradient: 'cyanGrad',
  },
  {
    type: 'الوزن',
    label: 'الوزن',
    unit: 'kg',
    icon: Scale,
    iconColor: 'text-green-600 bg-green-500/10',
    chartColor: '#22c55e',
    chartGradient: 'greenGrad',
  },
]

const META_BY_TYPE: Record<MetricType, MetricMeta> = METRIC_META.reduce(
  (acc, m) => {
    acc[m.type] = m
    return acc
  },
  {} as Record<MetricType, MetricMeta>
)

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Extract numeric value from a metric value string. For blood pressure
 *  "120/80", returns the systolic value (120). */
function toNumeric(value: string): number {
  const cleaned = value.trim().split('/')[0]
  const parsed = Number(cleaned)
  return Number.isNaN(parsed) ? 0 : parsed
}

/** Format a date string into a short MM/DD label. */
function shortDate(iso: string): string {
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return iso
  const mm = String(d.getMonth() + 1).padStart(2, '0')
  const dd = String(d.getDate()).padStart(2, '0')
  return `${mm}/${dd}`
}

function fullDate(iso: string): string {
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return iso
  return d.toLocaleDateString('ar-EG', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  })
}

function todayISO(): string {
  const d = new Date()
  const mm = String(d.getMonth() + 1).padStart(2, '0')
  const dd = String(d.getDate()).padStart(2, '0')
  return `${d.getFullYear()}-${mm}-${dd}`
}

interface ChartPoint {
  date: string
  value: number
  raw: string
}

/** Build ascending sorted chart points for a given metric type. */
function buildChartData(metrics: HealthMetric[], type: MetricType): ChartPoint[] {
  return metrics
    .filter((m) => m.type === type)
    .slice()
    .sort((a, b) => new Date(a.recordedAt).getTime() - new Date(b.recordedAt).getTime())
    .map((m) => ({
      date: shortDate(m.recordedAt),
      value: toNumeric(m.value),
      raw: m.value,
    }))
}

/** Latest + previous metric for a given type, sorted descending by date. */
function latestForType(
  metrics: HealthMetric[],
  type: MetricType
): { latest: HealthMetric | null; previous: HealthMetric | null } {
  const sorted = metrics
    .filter((m) => m.type === type)
    .slice()
    .sort((a, b) => new Date(b.recordedAt).getTime() - new Date(a.recordedAt).getTime())
  return { latest: sorted[0] ?? null, previous: sorted[1] ?? null }
}

// ---------------------------------------------------------------------------
// Chart tooltip
// ---------------------------------------------------------------------------

interface ChartTooltipProps {
  active?: boolean
  payload?: Array<{ payload: ChartPoint }>
  unit: string
  label?: string
}

function ChartTooltip({ active, payload, unit, label }: ChartTooltipProps) {
  if (!active || !payload || payload.length === 0) return null
  const point = payload[0].payload
  return (
    <div className="rounded-lg border border-border bg-popover p-3 shadow-md text-right" dir="rtl">
      <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
        <Calendar className="h-3 w-3" />
        {label}
      </div>
      <div className="text-sm font-semibold text-foreground">
        القيمة: {point.raw} <span className="text-muted-foreground font-normal">({unit})</span>
      </div>
    </div>
  )
}

// ---------------------------------------------------------------------------
// Sub-components
// ---------------------------------------------------------------------------

interface SummaryCardProps {
  meta: MetricMeta
  latest: HealthMetric | null
  previous: HealthMetric | null
}

function SummaryCard({ meta, latest, previous }: SummaryCardProps) {
  const Icon = meta.icon
  let trend: 'up' | 'down' | 'flat' | 'none' = 'none'
  if (latest && previous) {
    const diff = toNumeric(latest.value) - toNumeric(previous.value)
    if (diff > 0) trend = 'up'
    else if (diff < 0) trend = 'down'
    else trend = 'flat'
  }

  const TrendIcon =
    trend === 'up' ? TrendingUp : trend === 'down' ? TrendingDown : trend === 'flat' ? Minus : null
  const trendColor =
    trend === 'up'
      ? 'text-rose-500'
      : trend === 'down'
        ? 'text-emerald-500'
        : 'text-muted-foreground'

  return (
    <Card className="hover:shadow-md hover:border-primary/30 transition-all overflow-hidden">
      <CardContent className="p-4 md:p-5">
        <div className="flex items-start justify-between mb-3">
          <div className={`inline-flex p-2.5 rounded-lg ${meta.iconColor}`}>
            <Icon className="h-5 w-5" />
          </div>
          {TrendIcon && (
            <div className={`flex items-center gap-1 text-xs ${trendColor}`}>
              <TrendIcon className="h-3.5 w-3.5" />
              <span>
                {trend === 'up' && 'مرتفع'}
                {trend === 'down' && 'منخفض'}
                {trend === 'flat' && 'ثابت'}
              </span>
            </div>
          )}
        </div>
        <div className="text-xs text-muted-foreground">{meta.label}</div>
        <div className="flex items-baseline gap-1 mt-1">
          <span className="text-2xl md:text-3xl font-bold text-foreground">
            {latest ? latest.value : '—'}
          </span>
          {latest && (
            <span className="text-xs text-muted-foreground">{latest.unit}</span>
          )}
        </div>
        {latest && (
          <div className="text-[11px] text-muted-foreground mt-1 flex items-center gap-1">
            <Calendar className="h-3 w-3" />
            {fullDate(latest.recordedAt)}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

function SummarySkeleton() {
  return (
    <Card>
      <CardContent className="p-4 md:p-5">
        <div className="flex items-start justify-between mb-3">
          <div className="h-10 w-10 bg-muted animate-pulse rounded-lg" />
          <div className="h-4 w-12 bg-muted animate-pulse rounded" />
        </div>
        <div className="h-3 w-20 bg-muted animate-pulse rounded mb-2" />
        <div className="h-7 w-24 bg-muted animate-pulse rounded" />
      </CardContent>
    </Card>
  )
}

// ---------------------------------------------------------------------------
// Main component
// ---------------------------------------------------------------------------

export function MetricsView() {
  const [metrics, setMetrics] = useState<HealthMetric[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  // Form state
  const [formType, setFormType] = useState<MetricType>('ضغط الدم')
  const [formValue, setFormValue] = useState('')
  const [formUnit, setFormUnit] = useState('mmHg')
  const [formDate, setFormDate] = useState(todayISO())
  const [formNotes, setFormNotes] = useState('')

  // Active chart tab
  const [activeTab, setActiveTab] = useState<MetricType>('ضغط الدم')

  useEffect(() => {
    void loadMetrics()
  }, [])

  async function loadMetrics() {
    try {
      setLoading(true)
      const res = await metricsApi.list()
      setMetrics(res.metrics)
    } catch (err) {
      console.error(err)
      toast.error('تعذّر تحميل القياسات الصحية')
    } finally {
      setLoading(false)
    }
  }

  function handleTypeChange(type: MetricType) {
    setFormType(type)
    // Auto-suggest unit based on the selected type
    setFormUnit(META_BY_TYPE[type].unit)
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!formValue.trim()) {
      toast.error('الرجاء إدخال القيمة')
      return
    }
    try {
      setSubmitting(true)
      const recordedAt = formDate ? new Date(formDate).toISOString() : undefined
      await metricsApi.create({
        type: formType,
        value: formValue.trim(),
        unit: formUnit.trim() || META_BY_TYPE[formType].unit,
        recordedAt,
        notes: formNotes.trim() || undefined,
      })
      toast.success('تمت إضافة القياس بنجاح')
      // Reset form
      setFormValue('')
      setFormNotes('')
      setDialogOpen(false)
      await loadMetrics()
    } catch (err) {
      console.error(err)
      toast.error('فشل في إضافة القياس')
    } finally {
      setSubmitting(false)
    }
  }

  // Derived data
  const summaries = useMemo(() => {
    return METRIC_META.map((meta) => {
      const { latest, previous } = latestForType(metrics, meta.type)
      return { meta, latest, previous }
    })
  }, [metrics])

  const chartData = useMemo(() => {
    return buildChartData(metrics, activeTab)
  }, [metrics, activeTab])

  const activeMeta = META_BY_TYPE[activeTab]

  const recentMetrics = useMemo(() => {
    return metrics
      .slice()
      .sort((a, b) => new Date(b.recordedAt).getTime() - new Date(a.recordedAt).getTime())
      .slice(0, 8)
  }, [metrics])

  const isEmpty = !loading && metrics.length === 0

  return (
    <div className="space-y-6 animate-fade-in-up" dir="rtl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-2xl md:text-3xl font-bold flex items-center gap-2">
            <Activity className="h-6 w-6 text-primary" />
            القياسات الصحية
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            تابع مؤشراتك الصحية واطّلع على تطوّرها عبر الزمن
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90">
              <Plus className="h-4 w-4" />
              إضافة قياس
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Plus className="h-4 w-4 text-primary" />
                إضافة قياس صحي جديد
              </DialogTitle>
              <DialogDescription>
                أدخل بيانات القياس لحفظه في سجلك الصحي
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="metric-type">نوع القياس</Label>
                <Select
                  value={formType}
                  onValueChange={(v) => handleTypeChange(v as MetricType)}
                >
                  <SelectTrigger id="metric-type">
                    <SelectValue placeholder="اختر نوع القياس" />
                  </SelectTrigger>
                  <SelectContent>
                    {METRIC_META.map((m) => (
                      <SelectItem key={m.type} value={m.type}>
                        {m.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="metric-value">القيمة</Label>
                <Input
                  id="metric-value"
                  value={formValue}
                  onChange={(e) => setFormValue(e.target.value)}
                  placeholder={formType === 'ضغط الدم' ? 'مثال: 120/80' : 'أدخل القيمة'}
                  dir="ltr"
                  className="text-right"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="metric-unit">الوحدة</Label>
                  <Input
                    id="metric-unit"
                    value={formUnit}
                    onChange={(e) => setFormUnit(e.target.value)}
                    dir="ltr"
                    className="text-right"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="metric-date">التاريخ</Label>
                  <Input
                    id="metric-date"
                    type="date"
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    dir="ltr"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="metric-notes">ملاحظات (اختياري)</Label>
                <Input
                  id="metric-notes"
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder="أي ملاحظات إضافية..."
                />
              </div>

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setDialogOpen(false)}
                  disabled={submitting}
                >
                  إلغاء
                </Button>
                <Button type="submit" disabled={submitting} className="gap-2">
                  {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
                  {submitting ? 'جاري الحفظ...' : 'حفظ القياس'}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Empty state */}
      {isEmpty ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <div className="inline-flex p-4 rounded-full bg-primary/10 text-primary mb-4">
              <Activity className="h-8 w-8" />
            </div>
            <h3 className="text-lg font-semibold mb-1">لا توجد قياسات مسجّلة بعد</h3>
            <p className="text-sm text-muted-foreground max-w-sm">
              ابدأ بمتابعة صحتك بإضافة أول قياس. ستظهر هنا القياسات والرسوم البيانية.
            </p>
            <Button
              className="mt-4 gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
              onClick={() => setDialogOpen(true)}
            >
              <Plus className="h-4 w-4" />
              إضافة أول قياس
            </Button>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Summary cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
            {loading
              ? Array.from({ length: 4 }).map((_, i) => <SummarySkeleton key={i} />)
              : summaries.map(({ meta, latest, previous }) => (
                  <SummaryCard
                    key={meta.type}
                    meta={meta}
                    latest={latest}
                    previous={previous}
                  />
                ))}
          </div>

          {/* Charts section */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <TrendingUp className="h-4 w-4 text-primary" />
                تطوّر القياسات
              </CardTitle>
              <CardDescription>
                اضغط على نوع القياس لعرض الرسم البياني الخاص به
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="h-[280px] w-full bg-muted animate-pulse rounded-lg" />
              ) : (
                <Tabs
                  value={activeTab}
                  onValueChange={(v) => setActiveTab(v as MetricType)}
                  className="w-full"
                >
                  <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 mb-4 h-auto">
                    {METRIC_META.map((m) => {
                      const Icon = m.icon
                      return (
                        <TabsTrigger
                          key={m.type}
                          value={m.type}
                          className="flex items-center gap-1.5 py-2 text-xs sm:text-sm"
                        >
                          <Icon className="h-3.5 w-3.5" />
                          <span className="truncate">{m.label}</span>
                        </TabsTrigger>
                      )
                    })}
                  </TabsList>

                  {METRIC_META.map((meta) => {
                    const data = buildChartData(metrics, meta.type)
                    return (
                      <TabsContent key={meta.type} value={meta.type} className="mt-0">
                        {data.length === 0 ? (
                          <div className="flex flex-col items-center justify-center py-10 text-center text-sm text-muted-foreground">
                            <ClipboardList className="h-8 w-8 mb-2 opacity-50" />
                            لا توجد بيانات كافية لعرض هذا القياس
                          </div>
                        ) : (
                          <div className="w-full">
                            <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                              <div className="flex items-center gap-2">
                                <Badge
                                  variant="secondary"
                                  className="bg-primary/10 text-primary"
                                >
                                  {meta.label}
                                </Badge>
                                <span className="text-xs text-muted-foreground">
                                  الوحدة: {meta.unit}
                                </span>
                              </div>
                              <div className="text-xs text-muted-foreground">
                                عدد القراءات: {data.length}
                              </div>
                            </div>
                            <div className="w-full" style={{ height: 280 }}>
                              <ResponsiveContainer width="100%" height="100%">
                                <AreaChart
                                  data={data}
                                  margin={{ top: 8, right: 8, left: 8, bottom: 8 }}
                                >
                                  <defs>
                                    <linearGradient id={meta.chartGradient} x1="0" y1="0" x2="0" y2="1">
                                      <stop offset="5%" stopColor={meta.chartColor} stopOpacity={0.35} />
                                      <stop offset="95%" stopColor={meta.chartColor} stopOpacity={0} />
                                    </linearGradient>
                                  </defs>
                                  <CartesianGrid
                                    strokeDasharray="3 3"
                                    className="text-border"
                                    stroke="currentColor"
                                    strokeOpacity={0.4}
                                  />
                                  <XAxis
                                    dataKey="date"
                                    tick={{ fontSize: 12 }}
                                    className="fill-muted-foreground"
                                    axisLine={false}
                                    tickLine={false}
                                    reversed
                                  />
                                  <YAxis
                                    tick={{ fontSize: 12 }}
                                    className="fill-muted-foreground"
                                    axisLine={false}
                                    tickLine={false}
                                    width={40}
                                    orientation="right"
                                  />
                                  <Tooltip
                                    content={<ChartTooltip unit={meta.unit} />}
                                  />
                                  <Area
                                    type="monotone"
                                    dataKey="value"
                                    stroke={meta.chartColor}
                                    strokeWidth={2.5}
                                    fill={`url(#${meta.chartGradient})`}
                                    dot={{ r: 3, fill: meta.chartColor, strokeWidth: 0 }}
                                    activeDot={{ r: 5, fill: meta.chartColor, strokeWidth: 2, stroke: '#fff' }}
                                  />
                                </AreaChart>
                              </ResponsiveContainer>
                            </div>
                          </div>
                        )}
                      </TabsContent>
                    )
                  })}
                </Tabs>
              )}
            </CardContent>
          </Card>

          {/* Recent records */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <ClipboardList className="h-4 w-4 text-primary" />
                أحدث القياسات
              </CardTitle>
              <CardDescription>آخر القياسات الصحية المسجّلة</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="space-y-2">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div
                      key={i}
                      className="h-12 bg-muted animate-pulse rounded-lg"
                    />
                  ))}
                </div>
              ) : recentMetrics.length === 0 ? (
                <div className="py-8 text-center text-sm text-muted-foreground">
                  لا توجد قياسات لعرضها
                </div>
              ) : (
                <div className="max-h-96 overflow-y-auto custom-scrollbar pr-1 -mr-1">
                  <ul className="space-y-2">
                    {recentMetrics.map((m) => {
                      const meta =
                        META_BY_TYPE[m.type as MetricType] ?? null
                      const Icon = meta?.icon ?? Activity
                      const iconColor = meta?.iconColor ?? 'text-primary bg-primary/10'
                      return (
                        <li
                          key={m.id}
                          className="flex items-center gap-3 p-3 rounded-lg border border-border bg-card hover:bg-accent/40 transition-colors"
                        >
                          <div className={`inline-flex p-2 rounded-lg ${iconColor} shrink-0`}>
                            <Icon className="h-4 w-4" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-semibold text-sm">{m.type}</span>
                              <span className="text-xs text-muted-foreground">{m.unit}</span>
                            </div>
                            {m.notes && (
                              <div className="text-xs text-muted-foreground truncate mt-0.5">
                                {m.notes}
                              </div>
                            )}
                          </div>
                          <div className="text-left shrink-0">
                            <div className="font-bold text-sm" dir="ltr">
                              {m.value}
                            </div>
                            <div className="text-[11px] text-muted-foreground flex items-center gap-1 justify-end mt-0.5">
                              <Calendar className="h-3 w-3" />
                              {fullDate(m.recordedAt)}
                            </div>
                          </div>
                        </li>
                      )
                    })}
                  </ul>
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}

export default MetricsView
