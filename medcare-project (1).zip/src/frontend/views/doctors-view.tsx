'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { toast } from 'sonner'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Textarea } from '@/components/ui/textarea'
import { Skeleton } from '@/components/ui/skeleton'
import { Switch } from '@/components/ui/switch'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Stethoscope,
  Search,
  MapPin,
  Star,
  Clock,
  Languages,
  Award,
  CalendarPlus,
  Check,
  Users,
  Filter,
  X,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import {
  doctorsApi,
  appointmentsApi,
  type Doctor,
} from '@/frontend/lib/api'
import { useAppStore } from '@/frontend/stores/app-store'

// Available appointment time slots
const TIME_SLOTS = ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00']

// Appointment type options (Arabic)
const APPOINTMENT_TYPES = [
  { value: 'استشارة', label: 'استشارة' },
  { value: 'تطمين', label: 'تطمين' },
  { value: 'متابعة', label: 'متابعة' },
] as const

// Empty booking form state
interface BookingFormState {
  patientName: string
  patientEmail: string
  patientPhone: string
  date: string
  time: string
  type: string
  reason: string
}

const INITIAL_FORM: BookingFormState = {
  patientName: 'مريض',
  patientEmail: '',
  patientPhone: '',
  date: '',
  time: '',
  type: 'استشارة',
  reason: '',
}

/** Format the doctor fee with Arabic currency. */
function formatFee(fee: number): string {
  return new Intl.NumberFormat('ar-EG', {
    style: 'currency',
    currency: 'EGP',
    maximumFractionDigits: 0,
  }).format(fee)
}

/** Render N filled stars + remainder empty stars based on rating (0..5). */
function RatingStars({ rating, reviews }: { rating: number; reviews: number }) {
  const rounded = Math.round(rating)
  return (
    <div className="flex items-center gap-1" dir="ltr">
      <div className="flex items-center">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star
            key={i}
            className={cn(
              'h-3.5 w-3.5',
              i < rounded
                ? 'fill-amber-400 text-amber-400'
                : 'fill-muted text-muted',
            )}
          />
        ))}
      </div>
      <span className="text-xs font-semibold">{rating.toFixed(1)}</span>
      <span className="text-[11px] text-muted-foreground">
        ({reviews})
      </span>
    </div>
  )
}

/** Doctor card skeleton for loading state. */
function DoctorCardSkeleton() {
  return (
    <Card className="overflow-hidden">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-3">
          <Skeleton className="h-14 w-14 rounded-full" />
          <div className="flex-1 space-y-2">
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-3 w-1/2" />
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <Skeleton className="h-3 w-full" />
        <Skeleton className="h-3 w-2/3" />
        <div className="flex justify-between">
          <Skeleton className="h-6 w-20" />
          <Skeleton className="h-6 w-16" />
        </div>
        <Skeleton className="h-9 w-full" />
      </CardContent>
    </Card>
  )
}

export function DoctorsView() {
  const setActiveTab = useAppStore((s) => s.setActiveTab)

  // Data state
  const [doctors, setDoctors] = useState<Doctor[]>([])
  const [specialties, setSpecialties] = useState<string[]>([])
  const [loading, setLoading] = useState(true)

  // Filter state
  const [search, setSearch] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [specialty, setSpecialty] = useState<string>('all')
  const [availableOnly, setAvailableOnly] = useState(false)

  // Booking dialog state
  const [bookingOpen, setBookingOpen] = useState(false)
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [form, setForm] = useState<BookingFormState>(INITIAL_FORM)

  // Debounce search input
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search.trim()), 350)
    return () => clearTimeout(t)
  }, [search])

  // Fetch doctors whenever filters change
  useEffect(() => {
    let cancelled = false
    async function load() {
      setLoading(true)
      try {
        const res = await doctorsApi.list({
          search: debouncedSearch || undefined,
          specialty: specialty !== 'all' ? specialty : undefined,
          available: availableOnly || undefined,
        })
        if (cancelled) return
        setDoctors(res.doctors)
        setSpecialties(res.specialties)
      } catch (e) {
        if (!cancelled) {
          console.error('Doctors load error:', e)
          toast.error('تعذر تحميل قائمة الأطباء')
        }
      } finally {
        if (!cancelled) setLoading(false)
      }
    }
    load()
    return () => {
      cancelled = true
    }
  }, [debouncedSearch, specialty, availableOnly])

  // Reset form when dialog opens for a new doctor
  const openBooking = useCallback((doctor: Doctor) => {
    setSelectedDoctor(doctor)
    // Default date to tomorrow
    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)
    setForm({
      ...INITIAL_FORM,
      date: tomorrow.toISOString().slice(0, 10),
      time: TIME_SLOTS[0],
    })
    setBookingOpen(true)
  }, [])

  const closeBooking = useCallback(() => {
    setBookingOpen(false)
    setSelectedDoctor(null)
  }, [])

  const handleSubmit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault()
      if (!selectedDoctor) return

      // Basic validation
      if (!form.patientName.trim()) {
        toast.error('الرجاء إدخال الاسم')
        return
      }
      if (!form.patientEmail.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.patientEmail)) {
        toast.error('الرجاء إدخال بريد إلكتروني صحيح')
        return
      }
      if (!form.date) {
        toast.error('الرجاء اختيار التاريخ')
        return
      }
      if (!form.time) {
        toast.error('الرجاء اختيار الوقت')
        return
      }

      setSubmitting(true)
      try {
        await appointmentsApi.create({
          doctorId: selectedDoctor.id,
          patientName: form.patientName.trim(),
          patientEmail: form.patientEmail.trim(),
          patientPhone: form.patientPhone.trim() || undefined,
          date: form.date,
          time: form.time,
          type: form.type,
          reason: form.reason.trim() || undefined,
        })
        toast.success('تم حجز الموعد بنجاح', {
          description: `مع ${selectedDoctor.name} بتاريخ ${form.date} الساعة ${form.time}`,
        })
        closeBooking()
        setActiveTab('appointments')
      } catch (err) {
        const message =
          err instanceof Error ? err.message : 'حدث خطأ أثناء الحجز'
        toast.error('فشل الحجز', { description: message })
      } finally {
        setSubmitting(false)
      }
    },
    [form, selectedDoctor, closeBooking, setActiveTab],
  )

  const updateField = useCallback(
    <K extends keyof BookingFormState>(key: K, value: BookingFormState[K]) => {
      setForm((prev) => ({ ...prev, [key]: value }))
    },
    [],
  )

  const hasActiveFilters = useMemo(
    () => debouncedSearch !== '' || specialty !== 'all' || availableOnly,
    [debouncedSearch, specialty, availableOnly],
  )

  const clearFilters = useCallback(() => {
    setSearch('')
    setSpecialty('all')
    setAvailableOnly(false)
  }, [])

  return (
    <div className="space-y-6 animate-fade-in-up">
      {/* Header */}
      <div className="flex flex-col gap-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 className="flex items-center gap-2 text-2xl font-bold">
              <Stethoscope className="h-6 w-6 text-primary" />
              الأطباء
            </h2>
            <p className="mt-1 text-sm text-muted-foreground">
              تصفح نخبة من الأطباء المتخصصين واحجز موعدك بسهولة
            </p>
          </div>
          {!loading && (
            <Badge variant="secondary" className="gap-1.5 shrink-0">
              <Users className="h-3.5 w-3.5" />
              {doctors.length} طبيب
            </Badge>
          )}
        </div>

        {/* Search bar */}
        <div className="relative">
          <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث بالاسم أو التخصص أو المستشفى..."
            className="h-11 pr-10 pl-10"
            aria-label="بحث عن طبيب"
          />
          {search && (
            <button
              type="button"
              onClick={() => setSearch('')}
              className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full p-1 text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
              aria-label="مسح البحث"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Filters row */}
        <div className="flex flex-col sm:flex-row sm:items-center gap-3">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm font-medium text-muted-foreground">
              تصفية
            </span>
          </div>

          <Select value={specialty} onValueChange={setSpecialty}>
            <SelectTrigger className="h-10 w-full sm:w-56" aria-label="التخصص">
              <SelectValue placeholder="كل التخصصات" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل التخصصات</SelectItem>
              {specialties.map((s) => (
                <SelectItem key={s} value={s}>
                  {s}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <label
            htmlFor="available-only"
            className="flex items-center gap-2 cursor-pointer select-none rounded-lg border bg-card px-3 h-10 shrink-0"
          >
            <Switch
              id="available-only"
              checked={availableOnly}
              onCheckedChange={setAvailableOnly}
            />
            <span className="text-sm font-medium">المتاحون فقط</span>
          </label>

          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearFilters}
              className="h-10 gap-1.5 text-muted-foreground"
            >
              <X className="h-4 w-4" />
              مسح الفلاتر
            </Button>
          )}
        </div>
      </div>

      {/* Doctors grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <DoctorCardSkeleton key={i} />
          ))}
        </div>
      ) : doctors.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-muted">
              <Stethoscope className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-1">لا يوجد أطباء مطابقون</h3>
            <p className="text-sm text-muted-foreground max-w-sm mb-4">
              لم نعثر على أطباء يطابقون معايير البحث. جرّب تعديل الفلاتر أو مسحها.
            </p>
            {hasActiveFilters && (
              <Button onClick={clearFilters} variant="outline" className="gap-2">
                <X className="h-4 w-4" />
                مسح الفلاتر
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {doctors.map((doc) => (
            <DoctorCard key={doc.id} doctor={doc} onBook={openBooking} />
          ))}
        </div>
      )}

      {/* Booking dialog */}
      <Dialog open={bookingOpen} onOpenChange={setBookingOpen}>
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto custom-scrollbar">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-lg">
              <CalendarPlus className="h-5 w-5 text-primary" />
              حجز موعد
            </DialogTitle>
            <DialogDescription>
              {selectedDoctor
                ? `أدخل بياناتك لحجز موعد مع ${selectedDoctor.name}`
                : 'أدخل بياناتك لحجز موعد'}
            </DialogDescription>
          </DialogHeader>

          {selectedDoctor && (
            <div className="flex items-center gap-3 rounded-lg border bg-muted/40 p-3">
              <Avatar className="h-12 w-12 shrink-0">
                <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white font-bold text-base">
                  {selectedDoctor.name.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <div className="min-w-0">
                <div className="font-semibold text-sm truncate">
                  {selectedDoctor.name}
                </div>
                <div className="text-xs text-muted-foreground truncate">
                  {selectedDoctor.specialty}
                  {selectedDoctor.subSpecialty
                    ? ` · ${selectedDoctor.subSpecialty}`
                    : ''}
                </div>
              </div>
              <div className="ms-auto text-left">
                <div className="text-sm font-bold text-primary">
                  {formatFee(selectedDoctor.fee)}
                </div>
                <div className="text-[11px] text-muted-foreground">
                  رسوم الكشف
                </div>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="patient-name">اسم المريض</Label>
                <Input
                  id="patient-name"
                  value={form.patientName}
                  onChange={(e) => updateField('patientName', e.target.value)}
                  placeholder="الاسم الكامل"
                  className="h-10"
                  required
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="patient-email">البريد الإلكتروني</Label>
                <Input
                  id="patient-email"
                  type="email"
                  dir="ltr"
                  value={form.patientEmail}
                  onChange={(e) => updateField('patientEmail', e.target.value)}
                  placeholder="patient@example.com"
                  className="h-10 text-right"
                  required
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="patient-phone">رقم الهاتف (اختياري)</Label>
              <Input
                id="patient-phone"
                type="tel"
                dir="ltr"
                value={form.patientPhone}
                onChange={(e) => updateField('patientPhone', e.target.value)}
                placeholder="+20 100 000 0000"
                className="h-10 text-right"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="appt-date">التاريخ</Label>
                <Input
                  id="appt-date"
                  type="date"
                  value={form.date}
                  onChange={(e) => updateField('date', e.target.value)}
                  className="h-10"
                  required
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="appt-time">الوقت</Label>
                <Select
                  value={form.time}
                  onValueChange={(v) => updateField('time', v)}
                >
                  <SelectTrigger id="appt-time" className="h-10 w-full">
                    <SelectValue placeholder="اختر الوقت" />
                  </SelectTrigger>
                  <SelectContent>
                    {TIME_SLOTS.map((slot) => (
                      <SelectItem key={slot} value={slot}>
                        <span dir="ltr">{slot}</span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="appt-type">نوع الزيارة</Label>
              <Select
                value={form.type}
                onValueChange={(v) => updateField('type', v)}
              >
                <SelectTrigger id="appt-type" className="h-10 w-full">
                  <SelectValue placeholder="اختر النوع" />
                </SelectTrigger>
                <SelectContent>
                  {APPOINTMENT_TYPES.map((t) => (
                    <SelectItem key={t.value} value={t.value}>
                      {t.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="appt-reason">سبب الزيارة (اختياري)</Label>
              <Textarea
                id="appt-reason"
                value={form.reason}
                onChange={(e) => updateField('reason', e.target.value)}
                placeholder="صف الأعراض أو سبب الزيارة باختصار..."
                className="min-h-20 resize-none"
                rows={3}
              />
            </div>

            <DialogFooter className="gap-2 sm:gap-2 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={closeBooking}
                disabled={submitting}
                className="min-h-11"
              >
                إلغاء
              </Button>
              <Button
                type="submit"
                disabled={submitting}
                className="min-h-11 gap-2"
              >
                {submitting ? (
                  <>
                    <span className="h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground/40 border-t-primary-foreground" />
                    جاري الحجز...
                  </>
                ) : (
                  <>
                    <Check className="h-4 w-4" />
                    تأكيد الحجز
                  </>
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}

/** Single doctor card. */
function DoctorCard({
  doctor,
  onBook,
}: {
  doctor: Doctor
  onBook: (doctor: Doctor) => void
}) {
  return (
    <Card
      className={cn(
        'transition-all duration-200 hover:shadow-md hover:border-primary/30 flex flex-col',
        !doctor.available && 'opacity-80',
      )}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start gap-3">
          <Avatar className="h-14 w-14 shrink-0 border">
            <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white text-xl font-bold">
              {doctor.name.charAt(0)}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1">
            <CardTitle className="text-base font-semibold truncate">
              {doctor.name}
            </CardTitle>
            <div className="text-sm text-primary mt-0.5 truncate">
              {doctor.specialty}
            </div>
            {doctor.subSpecialty && (
              <div className="text-xs text-muted-foreground truncate mt-0.5">
                {doctor.subSpecialty}
              </div>
            )}
            <div className="mt-2">
              <RatingStars rating={doctor.rating} reviews={doctor.reviews} />
            </div>
          </div>
          <Badge
            variant={doctor.available ? 'default' : 'destructive'}
            className={cn(
              'shrink-0 gap-1',
              doctor.available
                ? 'bg-emerald-600 hover:bg-emerald-600 text-white'
                : '',
            )}
          >
            <span
              className={cn(
                'h-1.5 w-1.5 rounded-full',
                doctor.available
                  ? 'bg-white animate-medical-pulse'
                  : 'bg-white/80',
              )}
            />
            {doctor.available ? 'متاح' : 'غير متاح'}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col gap-3">
        {/* Hospital + location */}
        <div className="space-y-1.5 text-sm">
          {doctor.hospital && (
            <div className="flex items-start gap-2 text-muted-foreground">
              <MapPin className="h-3.5 w-3.5 mt-0.5 shrink-0" />
              <span className="truncate">
                {doctor.hospital}
                {doctor.location ? ` · ${doctor.location}` : ''}
              </span>
            </div>
          )}
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <Award className="h-3.5 w-3.5 shrink-0" />
              <span className="text-xs">{doctor.experience} سنوات خبرة</span>
            </span>
            {doctor.languages && (
              <span className="flex items-center gap-1.5">
                <Languages className="h-3.5 w-3.5 shrink-0" />
                <span className="text-xs truncate">{doctor.languages}</span>
              </span>
            )}
          </div>
        </div>

        {/* Footer: fee + book button */}
        <div className="mt-auto flex items-center justify-between gap-2 pt-3 border-t">
          <div>
            <div className="text-base font-bold text-primary">
              {formatFee(doctor.fee)}
            </div>
            <div className="text-[11px] text-muted-foreground">رسوم الكشف</div>
          </div>
          <Button
            onClick={() => onBook(doctor)}
            disabled={!doctor.available}
            className="min-h-11 gap-2"
            size="sm"
          >
            <CalendarPlus className="h-4 w-4" />
            احجز موعد
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
