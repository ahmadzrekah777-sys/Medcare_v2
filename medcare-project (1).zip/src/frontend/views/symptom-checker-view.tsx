'use client'

import { useEffect, useRef, useState } from 'react'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Textarea } from '@/components/ui/textarea'
import {
  Bot,
  Send,
  Sparkles,
  AlertCircle,
  Stethoscope,
  HeartPulse,
  RefreshCw,
  User,
  ShieldCheck,
} from 'lucide-react'
import { toast } from 'sonner'
import { symptomCheckerApi } from '@/frontend/lib/api'

interface ChatMessage {
  role: 'user' | 'assistant'
  content: string
}

const QUICK_SUGGESTIONS = [
  'لدي صداع مستمر',
  'ألم في الصدر',
  'ارتفاع في الحرارة',
  'ألم في المعدة',
]

export function SymptomCheckerView() {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)

  // Auto-scroll to bottom when messages or loading state change
  useEffect(() => {
    if (bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: 'smooth', block: 'end' })
    }
  }, [messages, loading])

  const handleSend = async (text?: string) => {
    const content = (text ?? input).trim()
    if (!content || loading) return

    const userMessage: ChatMessage = { role: 'user', content }
    // History = current messages BEFORE this new user message
    const history = messages.map((m) => ({ role: m.role, content: m.content }))

    setMessages((prev) => [...prev, userMessage])
    setInput('')
    setLoading(true)

    try {
      const data = await symptomCheckerApi.analyze(content, history)
      const aiResponse =
        data.response || data.message || 'عذراً، لم أتمكن من توليد رد مناسب.'

      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: aiResponse },
      ])
    } catch (err) {
      console.error('Symptom checker error:', err)
      toast.error('حدث خطأ أثناء التحليل. الرجاء المحاولة مرة أخرى.')
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          content:
            'عذراً، حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى أو استشارة الطبيب مباشرة.',
        },
      ])
    } finally {
      setLoading(false)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const handleNewChat = () => {
    if (messages.length === 0 && !loading) return
    setMessages([])
    setInput('')
    setLoading(false)
    toast.success('تم بدء محادثة جديدة')
  }

  const handleSuggestion = (suggestion: string) => {
    if (loading) return
    handleSend(suggestion)
  }

  return (
    <div className="max-w-3xl mx-auto animate-fade-in-up">
      {/* Header card */}
      <Card className="overflow-hidden border-none shadow-md mb-4">
        <CardContent className="p-4 md:p-6">
          <div className="flex items-center gap-3 md:gap-4">
            <div className="relative shrink-0">
              <div className="flex h-14 w-14 md:h-16 md:w-16 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-lg">
                <Bot className="h-7 w-7 md:h-8 md:w-8" />
              </div>
              <span className="absolute -bottom-0.5 -left-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-background ring-2 ring-background">
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-500 animate-medical-pulse" />
              </span>
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-lg md:text-xl font-bold leading-tight">
                  المساعد الطبي الذكي
                </h2>
                <Badge className="bg-primary/10 text-primary border-primary/20 hover:bg-primary/20 gap-1">
                  <Sparkles className="h-3 w-3" />
                  مدعوم بالـ AI
                </Badge>
              </div>
              <p className="text-xs md:text-sm text-muted-foreground mt-1">
                فحص الأعراض بالذكاء الاصطناعي
              </p>
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={handleNewChat}
              className="gap-1.5 shrink-0"
              disabled={messages.length === 0 && !loading}
            >
              <RefreshCw className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">محادثة جديدة</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Disclaimer banner */}
      <div className="mb-4 flex items-start gap-3 rounded-lg border border-amber-200 bg-amber-50 p-3 md:p-4 dark:border-amber-900/50 dark:bg-amber-950/30">
        <div className="shrink-0 rounded-md bg-amber-100 p-1.5 text-amber-600 dark:bg-amber-900/40 dark:text-amber-400">
          <AlertCircle className="h-4 w-4 md:h-5 md:w-5" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs md:text-sm text-amber-800 dark:text-amber-200 leading-relaxed">
            هذا المساعد لأغراض إرشادية فقط ولا يغني عن استشارة الطبيب. في الحالات
            الطارئة اتصل بالطوارئ 911 فوراً.
          </p>
        </div>
      </div>

      {/* Chat card */}
      <Card className="flex flex-col overflow-hidden">
        <CardHeader className="border-b bg-muted/30 py-3">
          <CardTitle className="flex items-center gap-2 text-sm">
            <HeartPulse className="h-4 w-4 text-primary" />
            المحادثة
            {messages.length > 0 && (
              <Badge variant="secondary" className="text-[10px] h-4">
                {messages.length} رسالة
              </Badge>
            )}
          </CardTitle>
        </CardHeader>

        {/* Messages area */}
        <ScrollArea className="flex-1 min-h-[400px] max-h-[60vh]">
          <div className="p-3 md:p-4 space-y-4">
            {messages.length === 0 && !loading ? (
              // Empty state - welcome message
              <div className="flex flex-col items-center justify-center text-center py-10 px-2 animate-fade-in-up">
                <div className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500/10 to-teal-600/10 text-primary mb-4">
                  <Stethoscope className="h-10 w-10" />
                </div>
                <h3 className="text-base md:text-lg font-semibold mb-2">
                  مرحباً! أنا مساعدك الطبي
                </h3>
                <p className="text-sm text-muted-foreground max-w-md leading-relaxed">
                  كيف يمكنني مساعدتك اليوم؟ صف لي الأعراض التي تشعر بها وسأحاول
                  تحليلها وتوجيهك للتخصص المناسب.
                </p>
                <div className="mt-4 flex items-center gap-1.5 text-xs text-muted-foreground">
                  <ShieldCheck className="h-3.5 w-3.5 text-primary" />
                  <span>خصوصية محمية • بياناتك آمنة</span>
                </div>
              </div>
            ) : (
              <>
                {messages.map((msg, i) => {
                  const isUser = msg.role === 'user'
                  return (
                    <div
                      key={i}
                      className={`flex gap-2 max-w-[85%] animate-fade-in-up ${
                        isUser ? 'mr-auto' : 'ml-auto'
                      }`}
                    >
                      {isUser ? (
                        <>
                          <div className="bg-primary text-primary-foreground rounded-2xl rounded-tr-sm px-4 py-2.5 text-sm leading-relaxed whitespace-pre-wrap break-words">
                            {msg.content}
                          </div>
                          <Avatar className="h-8 w-8 mt-1 shrink-0">
                            <AvatarFallback className="bg-primary/10 text-primary">
                              <User className="h-4 w-4" />
                            </AvatarFallback>
                          </Avatar>
                        </>
                      ) : (
                        <>
                          <Avatar className="h-8 w-8 mt-1 shrink-0">
                            <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
                              <Bot className="h-4 w-4" />
                            </AvatarFallback>
                          </Avatar>
                          <div className="bg-card border rounded-2xl rounded-tl-sm px-4 py-2.5 text-sm leading-relaxed whitespace-pre-wrap break-words">
                            {msg.content}
                          </div>
                        </>
                      )}
                    </div>
                  )
                })}

                {/* Typing indicator */}
                {loading && (
                  <div className="flex gap-2 ml-auto max-w-[85%] animate-fade-in-up">
                    <Avatar className="h-8 w-8 mt-1 shrink-0">
                      <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
                        <Bot className="h-4 w-4" />
                      </AvatarFallback>
                    </Avatar>
                    <div className="bg-card border rounded-2xl rounded-tl-sm px-4 py-3.5 flex items-center gap-1.5">
                      <span
                        className="h-2 w-2 rounded-full bg-primary/60 animate-medical-pulse"
                        style={{ animationDelay: '0ms' }}
                      />
                      <span
                        className="h-2 w-2 rounded-full bg-primary/60 animate-medical-pulse"
                        style={{ animationDelay: '200ms' }}
                      />
                      <span
                        className="h-2 w-2 rounded-full bg-primary/60 animate-medical-pulse"
                        style={{ animationDelay: '400ms' }}
                      />
                    </div>
                  </div>
                )}
              </>
            )}
            <div ref={bottomRef} />
          </div>
        </ScrollArea>

        {/* Quick suggestions */}
        {messages.length === 0 && (
          <div className="border-t bg-muted/30 p-3">
            <div className="flex flex-wrap gap-2">
              {QUICK_SUGGESTIONS.map((s) => (
                <Button
                  key={s}
                  variant="outline"
                  size="sm"
                  onClick={() => handleSuggestion(s)}
                  disabled={loading}
                  className="h-8 text-xs gap-1.5 rounded-full hover:border-primary/40 hover:bg-primary/5"
                >
                  <Sparkles className="h-3 w-3 text-primary" />
                  {s}
                </Button>
              ))}
            </div>
          </div>
        )}

        {/* Input area */}
        <div className="border-t p-3 md:p-4 bg-card">
          <div className="flex items-end gap-2">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="صف الأعراض التي تشعر بها..."
              rows={1}
              disabled={loading}
              className="min-h-[44px] max-h-32 resize-none flex-1"
            />
            <Button
              onClick={() => handleSend()}
              disabled={!input.trim() || loading}
              size="icon"
              className="h-11 w-11 shrink-0"
              aria-label="إرسال"
            >
              {loading ? (
                <RefreshCw className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </Button>
          </div>
          <p className="text-[10px] text-muted-foreground mt-2 text-center">
            اضغط Enter للإرسال • Shift+Enter لسطر جديد
          </p>
        </div>
      </Card>
    </div>
  )
}
