'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import { io, type Socket } from 'socket.io-client'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Video,
  Send,
  Phone,
  PhoneOff,
  Users,
  Circle,
  MessageSquare,
  Stethoscope,
  Wifi,
  WifiOff,
  User as UserIcon,
  Copy,
  Hash,
} from 'lucide-react'
import { toast } from 'sonner'

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------
interface Message {
  id: string
  roomId: string
  sender: string
  senderName: string
  content: string
  type: 'user' | 'system'
  timestamp?: string
}

interface OnlineUser {
  id: string
  username: string
  role: 'patient' | 'doctor'
}

type Role = 'patient' | 'doctor'

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
const generateRoomId = () =>
  `room-${Math.random().toString(36).slice(2, 6)}${Math.random()
    .toString(36)
    .slice(2, 5)}`

const formatTime = (ts?: string) => {
  if (!ts) return ''
  try {
    return new Date(ts).toLocaleTimeString('ar-EG', {
      hour: '2-digit',
      minute: '2-digit',
    })
  } catch {
    return ''
  }
}

const initials = (name: string) => name.trim().charAt(0) || '؟'

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------
export function TelemedicineView() {
  // socket reference
  const socketRef = useRef<Socket | null>(null)
  // auto-scroll reference
  const messagesEndRef = useRef<HTMLDivElement | null>(null)
  const scrollViewportRef = useRef<HTMLDivElement | null>(null)

  // connection / session state
  const [isConnected, setIsConnected] = useState(false)
  const [hasJoined, setHasJoined] = useState(false)
  // store the local socket id so we can compare message senders during render
  // (avoid accessing refs during render)
  const [socketId, setSocketId] = useState<string | null>(null)

  // form state (pre-join)
  const [username, setUsername] = useState('مريض')
  const [roomId, setRoomId] = useState(generateRoomId())
  const [role, setRole] = useState<Role>('patient')

  // chat state
  const [messages, setMessages] = useState<Message[]>([])
  const [onlineUsers, setOnlineUsers] = useState<OnlineUser[]>([])
  const [typingUser, setTypingUser] = useState<string | null>(null)
  const [input, setInput] = useState('')

  // pending join: store the join intent so we can emit once the socket connects
  // (using a ref avoids setState-in-effect lint issues)
  const pendingJoinRef = useRef<{ username: string; role: Role; roomId: string } | null>(null)
  const [isConnecting, setIsConnecting] = useState(false)

  // typing throttle ref
  const lastTypingEmitRef = useRef<number>(0)
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  // -------------------------------------------------------------------------
  // Initialize socket connection once on mount
  // -------------------------------------------------------------------------
  useEffect(() => {
    const socket = io('/?XTransformPort=3003', {
      transports: ['websocket', 'polling'],
      forceNew: true,
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
      timeout: 10000,
    })
    socketRef.current = socket

    socket.on('connect', () => {
      setIsConnected(true)
      setSocketId(socket.id)
      setIsConnecting(false)
      // If there's a pending join (user clicked join before connection), emit now
      const pending = pendingJoinRef.current
      if (pending) {
        socket.emit('join-room', pending)
        pendingJoinRef.current = null
        toast.success('تم الاتصال والانضمام إلى الغرفة', {
          description: `رقم الغرفة: ${pending.roomId}`,
        })
      } else {
        toast.success('تم الاتصال بخدمة الطب عن بعد', {
          description: 'يمكنك الآن بدء استشارة طبية',
        })
      }
    })

    socket.on('disconnect', () => {
      setIsConnected(false)
      setSocketId(null)
      setIsConnecting(false)
      toast.error('انقطع الاتصال', {
        description: 'يتم محاولة إعادة الاتصال...',
      })
    })

    socket.on('connect_error', () => {
      setIsConnected(false)
      setIsConnecting(false)
    })

    socket.on('message', (msg: Message) => {
      setMessages((prev) => [...prev, msg])
    })

    socket.on('users-list', (data: { users: OnlineUser[] }) => {
      setOnlineUsers(data.users || [])
    })

    socket.on('typing', (data: { username: string; isTyping: boolean }) => {
      setTypingUser(data.isTyping ? data.username : null)
    })

    return () => {
      socket.removeAllListeners()
      socket.disconnect()
      socketRef.current = null
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current)
    }
  }, [])

  // -------------------------------------------------------------------------
  // Auto-scroll to the newest message
  // -------------------------------------------------------------------------
  const scrollToBottom = useCallback(() => {
    if (scrollViewportRef.current) {
      scrollViewportRef.current.scrollTop =
        scrollViewportRef.current.scrollHeight
    }
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [])

  useEffect(() => {
    scrollToBottom()
  }, [messages, scrollToBottom])

  // -------------------------------------------------------------------------
  // Join the room
  // -------------------------------------------------------------------------
  const handleJoin = () => {
    const socket = socketRef.current
    if (!socket) return

    const trimmedName = username.trim() || 'مريض'
    const trimmedRoom = roomId.trim() || generateRoomId()

    setMessages([])
    setOnlineUsers([])
    setTypingUser(null)
    setHasJoined(true)

    const joinData = { username: trimmedName, role, roomId: trimmedRoom }

    if (isConnected) {
      socket.emit('join-room', joinData)
      toast.success('تم الانضمام إلى الغرفة', {
        description: `رقم الغرفة: ${trimmedRoom}`,
      })
    } else {
      // Socket not yet connected — store intent, will emit on connect
      pendingJoinRef.current = joinData
      setIsConnecting(true)
      toast.info('جاري الاتصال بالخادم...', {
        description: 'سيتم الانضمام للغرفة تلقائياً عند الاتصال',
      })
    }
  }

  // Clear connecting flag on disconnect/error

  // -------------------------------------------------------------------------
  // Leave / end the call
  // -------------------------------------------------------------------------
  const handleLeave = () => {
    const socket = socketRef.current
    if (socket) {
      // graceful: disconnect leaves the room on server side via disconnect handler
      socket.disconnect()
      // reconnect so the user could join another room
      socket.connect()
    }
    setHasJoined(false)
    setMessages([])
    setOnlineUsers([])
    setTypingUser(null)
    setInput('')
    toast.info('تم إنهاء المكالمة', {
      description: 'نتمنى لك دوام الصحة والعافية',
    })
  }

  // -------------------------------------------------------------------------
  // Send a message
  // -------------------------------------------------------------------------
  const handleSend = () => {
    const socket = socketRef.current
    const content = input.trim()
    if (!socket || !content || !hasJoined) return

    socket.emit('message', { content })
    // clear typing state
    socket.emit('typing', { isTyping: false })
    setTypingUser(null)
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current)
    setInput('')
  }

  // -------------------------------------------------------------------------
  // Typing indicator (throttled)
  // -------------------------------------------------------------------------
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setInput(value)
    const socket = socketRef.current
    if (!socket || !hasJoined) return

    const now = Date.now()
    if (now - lastTypingEmitRef.current > 1200) {
      socket.emit('typing', { isTyping: true })
      lastTypingEmitRef.current = now
    }

    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current)
    typingTimeoutRef.current = setTimeout(() => {
      socket.emit('typing', { isTyping: false })
      setTypingUser(null)
    }, 1800)
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const copyRoomId = async () => {
    try {
      await navigator.clipboard.writeText(roomId)
      toast.success('تم نسخ رقم الغرفة', {
        description: roomId,
      })
    } catch {
      toast.error('تعذّر نسخ رقم الغرفة')
    }
  }

  // -------------------------------------------------------------------------
  // Render: Pre-join screen
  // -------------------------------------------------------------------------
  if (!hasJoined) {
    return (
      <div
        dir="rtl"
        className="animate-fade-in-up max-w-2xl mx-auto"
      >
        <Card className="overflow-hidden border-none shadow-xl">
          {/* Header band */}
          <div className="relative bg-gradient-to-l from-emerald-600 via-teal-600 to-cyan-600 p-6 md:p-8 text-white">
            <div className="absolute top-0 left-0 h-full w-1/3 opacity-10">
              <Stethoscope className="h-full w-full" />
            </div>
            <div className="relative z-10 flex items-start gap-4">
              <div className="shrink-0 p-3 rounded-2xl bg-white/15 backdrop-blur-sm">
                <Video className="h-8 w-8" />
              </div>
              <div className="flex-1">
                <Badge className="mb-2 bg-white/20 text-white border-none hover:bg-white/30">
                  خدمة Telemedicine
                </Badge>
                <h2 className="text-2xl md:text-3xl font-bold mb-1">
                  الطب عن بعد
                </h2>
                <p className="text-white/90 text-sm md:text-base">
                  استشارة طبية فورية — تحدّث مع طبيبك مباشرة عبر مكالمة نصية آمنة
                </p>
              </div>
            </div>
          </div>

          <CardContent className="p-6 md:p-8 space-y-5">
            {/* connection status pill */}
            <div className="flex items-center justify-end gap-2 text-xs">
              {isConnected ? (
                <Badge
                  variant="secondary"
                  className="bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 gap-1.5"
                >
                  <Wifi className="h-3 w-3" />
                  الخادم متصل
                </Badge>
              ) : (
                <Badge
                  variant="secondary"
                  className="bg-rose-500/10 text-rose-700 dark:text-rose-400 gap-1.5"
                >
                  <WifiOff className="h-3 w-3" />
                  جارٍ الاتصال بالخادم...
                </Badge>
              )}
            </div>

            {/* username */}
            <div className="space-y-2">
              <label
                htmlFor="telemedicine-username"
                className="text-sm font-medium flex items-center gap-2"
              >
                <UserIcon className="h-4 w-4 text-primary" />
                الاسم
              </label>
              <Input
                id="telemedicine-username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="اكتب اسمك هنا"
                maxLength={40}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleJoin()
                }}
              />
            </div>

            {/* room id */}
            <div className="space-y-2">
              <label
                htmlFor="telemedicine-room"
                className="text-sm font-medium flex items-center gap-2"
              >
                <Hash className="h-4 w-4 text-primary" />
                رقم الغرفة
              </label>
              <div className="flex gap-2">
                <Input
                  id="telemedicine-room"
                  value={roomId}
                  onChange={(e) => setRoomId(e.target.value)}
                  placeholder="room-XXXX"
                  className="font-mono"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleJoin()
                  }}
                />
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={() => setRoomId(generateRoomId())}
                  title="توليد رقم غرفة جديد"
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                شارك رقم الغرفة مع الطبيب ليتمكن من الانضمام إلى نفس المكالمة
              </p>
            </div>

            {/* role selector */}
            <div className="space-y-2">
              <label className="text-sm font-medium flex items-center gap-2">
                <Stethoscope className="h-4 w-4 text-primary" />
                الدور
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setRole('patient')}
                  className={`flex flex-col items-center gap-2 rounded-xl border-2 p-4 transition-all ${
                    role === 'patient'
                      ? 'border-primary bg-primary/5 shadow-sm'
                      : 'border-border hover:border-primary/40 hover:bg-accent/50'
                  }`}
                >
                  <UserIcon
                    className={`h-6 w-6 ${
                      role === 'patient'
                        ? 'text-primary'
                        : 'text-muted-foreground'
                    }`}
                  />
                  <span className="text-sm font-semibold">مريض</span>
                </button>
                <button
                  type="button"
                  onClick={() => setRole('doctor')}
                  className={`flex flex-col items-center gap-2 rounded-xl border-2 p-4 transition-all ${
                    role === 'doctor'
                      ? 'border-primary bg-primary/5 shadow-sm'
                      : 'border-border hover:border-primary/40 hover:bg-accent/50'
                  }`}
                >
                  <Stethoscope
                    className={`h-6 w-6 ${
                      role === 'doctor'
                        ? 'text-primary'
                        : 'text-muted-foreground'
                    }`}
                  />
                  <span className="text-sm font-semibold">طبيب</span>
                </button>
              </div>
            </div>

            <Separator />

            {/* join button */}
            <Button
              onClick={handleJoin}
              disabled={!username.trim() || !roomId.trim()}
              className="w-full h-12 text-base gap-2 bg-gradient-to-l from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
            >
              <Phone className="h-5 w-5" />
              ابدأ المكالمة
            </Button>

            <p className="text-center text-xs text-muted-foreground flex items-center justify-center gap-1.5">
              <Circle className="h-2 w-2 fill-emerald-500 text-emerald-500" />
              اتصال مشفّر وآمن — لا يتم تخزين الرسائل
            </p>
          </CardContent>
        </Card>
      </div>
    )
  }

  // -------------------------------------------------------------------------
  // Render: Active chat screen
  // -------------------------------------------------------------------------
  return (
    <div
      dir="rtl"
      className="animate-fade-in-up max-w-4xl mx-auto"
    >
      <Card className="border-none shadow-xl overflow-hidden">
        {/* Top bar */}
        <CardHeader className="bg-gradient-to-l from-emerald-600 via-teal-600 to-cyan-600 text-white p-0">
          <div className="flex items-center justify-between gap-3 p-4 md:p-5">
            <div className="flex items-center gap-3 min-w-0">
              <div className="shrink-0 p-2.5 rounded-xl bg-white/15 backdrop-blur-sm">
                <Video className="h-5 w-5" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <CardTitle className="text-base md:text-lg truncate">
                    استشارة طبية فورية
                  </CardTitle>
                </div>
                <div className="flex items-center gap-2 mt-0.5 text-xs text-white/80">
                  <Hash className="h-3 w-3" />
                  <span className="font-mono truncate">{roomId}</span>
                  <button
                    type="button"
                    onClick={copyRoomId}
                    className="hover:bg-white/20 rounded p-0.5 transition-colors"
                    title="نسخ رقم الغرفة"
                  >
                    <Copy className="h-3 w-3" />
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 md:gap-3 shrink-0">
              {/* connection status */}
              <Badge
                className={`gap-1.5 border-none ${
                  isConnected
                    ? 'bg-white/20 text-white'
                    : isConnecting
                    ? 'bg-amber-500/30 text-white'
                    : 'bg-rose-500/30 text-white'
                }`}
              >
                <Circle
                  className={`h-2.5 w-2.5 ${
                    isConnected
                      ? 'fill-emerald-300 text-emerald-300 animate-medical-pulse'
                      : isConnecting
                      ? 'fill-amber-300 text-amber-300 animate-medical-pulse'
                      : 'fill-rose-300 text-rose-300'
                  }`}
                />
                <span className="hidden sm:inline">
                  {isConnected ? 'متصل' : isConnecting ? 'جاري الاتصال...' : 'غير متصل'}
                </span>
              </Badge>

              {/* online users count */}
              <Badge className="gap-1.5 bg-white/20 text-white border-none">
                <Users className="h-3.5 w-3.5" />
                {onlineUsers.length}
              </Badge>

              {/* end call */}
              <Button
                onClick={handleLeave}
                variant="destructive"
                size="sm"
                className="gap-1.5 bg-rose-600 hover:bg-rose-700"
              >
                <PhoneOff className="h-4 w-4" />
                <span className="hidden sm:inline">إنهاء المكالمة</span>
              </Button>
            </div>
          </div>

          {/* Online users avatars row */}
          {onlineUsers.length > 0 && (
            <>
              <Separator className="bg-white/20" />
              <div className="flex items-center gap-2 px-4 md:px-5 py-3 overflow-x-auto custom-scrollbar">
                <span className="text-xs text-white/70 shrink-0 flex items-center gap-1">
                  <Users className="h-3 w-3" />
                  الموجودون:
                </span>
                <div className="flex items-center gap-2">
                  {onlineUsers.map((u) => (
                    <div
                      key={u.id}
                      className="flex items-center gap-1.5 bg-white/10 rounded-full pr-1.5 pl-2.5 py-1"
                    >
                      <Avatar className="h-6 w-6 border border-white/30">
                        <AvatarFallback
                          className={`text-[10px] font-bold ${
                            u.role === 'doctor'
                              ? 'bg-cyan-200 text-cyan-800'
                              : 'bg-emerald-200 text-emerald-800'
                          }`}
                        >
                          {initials(u.username)}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-xs text-white/90 font-medium">
                        {u.username}
                      </span>
                      <Badge
                        variant="secondary"
                        className={`text-[9px] h-4 px-1 gap-0.5 ${
                          u.role === 'doctor'
                            ? 'bg-cyan-500/30 text-white border-none'
                            : 'bg-emerald-500/30 text-white border-none'
                        }`}
                      >
                        {u.role === 'doctor' ? (
                          <Stethoscope className="h-2.5 w-2.5" />
                        ) : (
                          <UserIcon className="h-2.5 w-2.5" />
                        )}
                        {u.role === 'doctor' ? 'طبيب' : 'مريض'}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </CardHeader>

        <CardContent className="p-0 flex flex-col">
          {/* Messages area */}
          <div className="relative">
            <ScrollArea className="h-[420px] md:h-[460px] w-full">
              <div
                ref={scrollViewportRef}
                className="p-4 md:p-5 space-y-3 min-h-[420px] md:min-h-[460px]"
              >
                {messages.length === 0 ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-muted-foreground">
                    <MessageSquare className="h-12 w-12 mb-3 opacity-20" />
                    <p className="text-sm font-medium">لا توجد رسائل بعد</p>
                    <p className="text-xs mt-1">
                      اكتب أول رسالة لبدء المحادثة مع الطبيب
                    </p>
                  </div>
                ) : (
                  messages.map((msg) => {
                    if (msg.type === 'system') {
                      return (
                        <div
                          key={msg.id}
                          className="flex justify-center my-2"
                        >
                          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-muted text-muted-foreground text-xs italic">
                            <Circle className="h-1.5 w-1.5 fill-muted-foreground text-muted-foreground" />
                            {msg.content}
                          </div>
                        </div>
                      )
                    }

                    const isOwn = socketId !== null && socketId === msg.sender
                    return (
                      <div
                        key={msg.id}
                        className={`flex flex-col ${
                          isOwn ? 'items-start' : 'items-end'
                        }`}
                      >
                        <div
                          className={`max-w-[80%] md:max-w-[70%] rounded-2xl px-3.5 py-2.5 ${
                            isOwn
                              ? 'bg-primary text-primary-foreground rounded-bl-sm'
                              : 'bg-muted rounded-br-sm'
                          }`}
                        >
                          {!isOwn && (
                            <div className="flex items-center gap-1.5 mb-1">
                              <span className="text-xs font-semibold text-primary">
                                {msg.senderName}
                              </span>
                            </div>
                          )}
                          <p className="text-sm whitespace-pre-wrap break-words leading-relaxed">
                            {msg.content}
                          </p>
                          <div
                            className={`text-[10px] mt-1 ${
                              isOwn
                                ? 'text-primary-foreground/70 text-left'
                                : 'text-muted-foreground'
                            }`}
                          >
                            {formatTime(msg.timestamp)}
                            {isOwn && ' • أنت'}
                          </div>
                        </div>
                      </div>
                    )
                  })
                )}

                {/* typing indicator */}
                {typingUser && (
                  <div className="flex items-end justify-end">
                    <div className="bg-muted rounded-2xl rounded-br-sm px-3.5 py-2.5">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs text-muted-foreground">
                          {typingUser} يكتب
                        </span>
                        <span className="flex gap-0.5">
                          <span
                            className="w-1.5 h-1.5 rounded-full bg-muted-foreground/70 animate-bounce"
                            style={{ animationDelay: '0ms' }}
                          />
                          <span
                            className="w-1.5 h-1.5 rounded-full bg-muted-foreground/70 animate-bounce"
                            style={{ animationDelay: '150ms' }}
                          />
                          <span
                            className="w-1.5 h-1.5 rounded-full bg-muted-foreground/70 animate-bounce"
                            style={{ animationDelay: '300ms' }}
                          />
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>
          </div>

          <Separator />

          {/* Input bar */}
          <div className="p-3 md:p-4 flex items-center gap-2 bg-card">
            <Input
              value={input}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              placeholder="اكتب رسالتك هنا..."
              disabled={!isConnected}
              className="flex-1 h-11"
              maxLength={500}
            />
            <Button
              onClick={handleSend}
              disabled={!isConnected || !input.trim()}
              size="icon"
              className="h-11 w-11 shrink-0 bg-gradient-to-l from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
            >
              <Send className="h-4 w-4" />
              <span className="sr-only">إرسال</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* footer note */}
      <p className="text-center text-xs text-muted-foreground mt-3 flex items-center justify-center gap-1.5">
        <Circle className="h-2 w-2 fill-emerald-500 text-emerald-500 animate-medical-pulse" />
        جلسة مشفّرة — يُرجى عدم مشاركة معلومات حساسة خارج هذه القناة الآمنة
      </p>
    </div>
  )
}

export default TelemedicineView
