'use client'

import { useEffect, useState } from 'react'
import { recordsApi, type MedicalRecord } from '@/frontend/lib/api'
import {
  Card,
  CardContent,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  FileText,
  Plus,
  Trash2,
  Loader2,
  FileSpreadsheet,
  Pill,
  Stethoscope,
  Image,
  Calendar,
  User,
  Search,
} from 'lucide-react'
import { toast } from 'sonner'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

const recordTypeIcons: Record<string, typeof FileText> = {
  'تحليل مخبري': FileSpreadsheet,
  'وصفة طبية': Pill,
  'تشخيص': Stethoscope,
  'أشعة': Image,
}

const recordTypeColors: Record<string, string> = {
  'تحليل مخبري': 'bg-cyan-500/10 text-cyan-600',
  'وصفة طبية': 'bg-emerald-500/10 text-emerald-600',
  'تشخيص': 'bg-teal-500/10 text-teal-600',
  'أشعة': 'bg-green-500/10 text-green-600',
}

export function RecordsView() {
  const [records, setRecords] = useState<MedicalRecord[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [search, setSearch] = useState('')
  const [viewRecord, setViewRecord] = useState<MedicalRecord | null>(null)
  const [form, setForm] = useState({
    title: '',
    type: 'تحليل مخبري',
    date: new Date().toISOString().split('T')[0],
    doctorName: '',
    description: '',
  })

  useEffect(() => {
    load()
  }, [])

  async function load() {
    setLoading(true)
    try {
      const data = await recordsApi.list()
      setRecords(data.records)
    } catch (e) {
      toast.error('فشل تحميل السجلات الطبية')
    } finally {
      setLoading(false)
    }
  }

  async function handleSubmit() {
    if (!form.title || !form.type || !form.date || !form.description) {
      toast.error('الرجاء ملء جميع الحقول المطلوبة')
      return
    }
    setSubmitting(true)
    try {
      await recordsApi.create(form)
      toast.success('تم إضافة السجل الطبي بنجاح')
      setDialogOpen(false)
      setForm({ title: '', type: 'تحليل مخبري', date: new Date().toISOString().split('T')[0], doctorName: '', description: '' })
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'فشل إضافة السجل')
    } finally {
      setSubmitting(false)
    }
  }

  async function handleDelete(id: string) {
    try {
      await recordsApi.delete(id)
      toast.success('تم حذف السجل')
      await load()
    } catch (e) {
      toast.error('فشل حذف السجل')
    }
  }

  const filtered = records.filter(
    (r) =>
      !search ||
      r.title.includes(search) ||
      r.type.includes(search) ||
      (r.doctorName?.includes(search) ?? false)
  )

  return (
    <div className="space-y-6 animate-fade-in-up">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <FileText className="h-6 w-6 text-primary" />
            السجلات الطبية
          </h2>
          <p className="text-sm text-muted-foreground mt-1">ملفك الطبي الكامل في مكان واحد</p>
        </div>
        <Button onClick={() => setDialogOpen(true)} className="gap-2">
          <Plus className="h-4 w-4" />
          إضافة سجل
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="ابحث في السجلات..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pr-10"
        />
      </div>

      {loading ? (
        <div className="grid md:grid-cols-2 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardContent className="p-5">
                <div className="h-24 bg-muted animate-pulse rounded-lg" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <FileText className="h-12 w-12 mx-auto text-muted-foreground/30 mb-3" />
            <p className="text-muted-foreground mb-4">
              {search ? 'لا توجد نتائج مطابقة' : 'لا توجد سجلات طبية'}
            </p>
            {!search && (
              <Button onClick={() => setDialogOpen(true)} className="gap-2">
                <Plus className="h-4 w-4" />
                أضف أول سجل
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 gap-4 max-h-[calc(100vh-300px)] overflow-y-auto custom-scrollbar pl-1">
          {filtered.map((record) => {
            const Icon = recordTypeIcons[record.type] || FileText
            const colorClass = recordTypeColors[record.type] || 'bg-muted text-muted-foreground'
            return (
              <Card key={record.id} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => setViewRecord(record)}>
                <CardContent className="p-5">
                  <div className="flex items-start gap-3">
                    <div className={`p-2.5 rounded-lg shrink-0 ${colorClass}`}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="font-semibold text-sm leading-tight">{record.title}</h3>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 shrink-0 text-destructive hover:text-destructive"
                          onClick={(e) => { e.stopPropagation(); handleDelete(record.id) }}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                      <Badge variant="outline" className="mt-1 text-xs">{record.type}</Badge>
                      <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{record.description}</p>
                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-3 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          {new Date(record.date).toLocaleDateString('ar')}
                        </span>
                        {record.doctorName && (
                          <span className="flex items-center gap-1">
                            <User className="h-3 w-3" />
                            {record.doctorName}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}

      {/* Add dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5 text-primary" />
              إضافة سجل طبي
            </DialogTitle>
            <DialogDescription>أضف سجلاً طبياً جديداً لملفك</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>العنوان *</Label>
              <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="مثال: تحليل الدم الشامل" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>النوع *</Label>
                <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="تحليل مخبري">تحليل مخبري</SelectItem>
                    <SelectItem value="وصفة طبية">وصفة طبية</SelectItem>
                    <SelectItem value="تشخيص">تشخيص</SelectItem>
                    <SelectItem value="أشعة">أشعة</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>التاريخ *</Label>
                <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
              </div>
            </div>
            <div className="space-y-2">
              <Label>الطبيب</Label>
              <Input value={form.doctorName} onChange={(e) => setForm({ ...form, doctorName: e.target.value })} placeholder="اسم الطبيب (اختياري)" />
            </div>
            <div className="space-y-2">
              <Label>الوصف *</Label>
              <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} placeholder="تفاصيل السجل الطبي..." />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
            <Button onClick={handleSubmit} disabled={submitting} className="gap-2">
              {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
              حفظ السجل
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View dialog */}
      <Dialog open={!!viewRecord} onOpenChange={(o) => !o && setViewRecord(null)}>
        <DialogContent className="max-w-md">
          {viewRecord && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  {(() => {
                    const Icon = recordTypeIcons[viewRecord.type] || FileText
                    return <Icon className="h-5 w-5 text-primary" />
                  })()}
                  {viewRecord.title}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Badge variant="outline">{viewRecord.type}</Badge>
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    {new Date(viewRecord.date).toLocaleDateString('ar')}
                  </span>
                </div>
                {viewRecord.doctorName && (
                  <div className="flex items-center gap-2 text-sm">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span>{viewRecord.doctorName}</span>
                  </div>
                )}
                <div className="rounded-lg bg-muted/50 p-3">
                  <p className="text-sm whitespace-pre-wrap leading-relaxed">{viewRecord.description}</p>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
