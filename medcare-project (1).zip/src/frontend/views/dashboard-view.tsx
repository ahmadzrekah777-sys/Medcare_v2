'use client'

import { useAppStore } from '@/frontend/stores/app-store'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  CalendarDays,
  Stethoscope,
  FileText,
  Activity,
  Bot,
  Video,
  Pill,
  HeartPulse,
  TrendingUp,
  Clock,
  ChevronLeft,
  Users,
  Award,
} from 'lucide-react'
import { useEffect, useState } from 'react'
import { appointmentsApi, metricsApi, doctorsApi, medicationsApi, type Doctor, type Appointment, type HealthMetric, type Medication } from '@/frontend/lib/api'

export function DashboardView() {
  const { setActiveTab } = useAppStore()
  const [stats, setStats] = useState({
    appointments: 0,
    doctors: 0,
    records: 5,
    medications: 0,
  })
  const [upcomingAppointments, setUpcomingAppointments] = useState<Appointment[]>([])
  const [latestMetrics, setLatestMetrics] = useState<HealthMetric[]>([])
  const [doctors, setDoctors] = useState<Doctor[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function load() {
      try {
        const [appts, metrics, docs, meds] = await Promise.all([
          appointmentsApi.list(),
          metricsApi.list(),
          doctorsApi.list(),
          medicationsApi.list(),
        ])
        setUpcomingAppointments(appts.appointments.slice(0, 3))
        setLatestMetrics(metrics.metrics.slice(0, 4))
        setDoctors(docs.doctors.slice(0, 4))
        setStats({
          appointments: appts.appointments.length,
          doctors: docs.doctors.length,
          records: 5,
          medications: meds.medications.filter((m) => m.active).length,
        })
      } catch (e) {
        console.error('Dashboard load error:', e)
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  const quickActions = [
    { label: 'حجز موعد', desc: 'احجز مع طبيب مختص', icon: CalendarDays, tab: 'doctors' as const, color: 'bg-emerald-500/10 text-emerald-600' },
    { label: 'فحص الأعراض', desc: 'تحليل ذكي بالـ AI', icon: Bot, tab: 'symptom-checker' as const, color: 'bg-teal-500/10 text-teal-600' },
    { label: 'الطب عن بعد', desc: 'استشارة فورية', icon: Video, tab: 'telemedicine' as const, color: 'bg-cyan-500/10 text-cyan-600' },
    { label: 'سجلاتي الطبية', desc: 'عرض الملف الطبي', icon: FileText, tab: 'records' as const, color: 'bg-green-500/10 text-green-600' },
  ]

  const statCards = [
    { label: 'مواعيدي', value: stats.appointments, icon: CalendarDays, color: 'text-emerald-600' },
    { label: 'الأطباء المتاحون', value: stats.doctors, icon: Users, color: 'text-teal-600' },
    { label: 'السجلات الطبية', value: stats.records, icon: FileText, color: 'text-cyan-600' },
    { label: 'الأدوية النشطة', value: stats.medications, icon: Pill, color: 'text-green-600' },
  ]

  return (
    <div className="space-y-6">
      {/* Hero banner */}
      <Card className="overflow-hidden border-none bg-gradient-to-l from-emerald-600 via-teal-600 to-cyan-600 text-white shadow-lg">
        <CardContent className="relative p-6 md:p-8">
          <div className="absolute top-0 left-0 h-full w-1/3 opacity-10">
            <HeartPulse className="h-full w-full" />
          </div>
          <div className="relative z-10 max-w-2xl">
            <Badge className="mb-3 bg-white/20 text-white border-none hover:bg-white/30">
              منصة طبية متكاملة
            </Badge>
            <h2 className="text-2xl md:text-3xl font-bold mb-2">
              أهلاً بك في MedCare 👋
            </h2>
            <p className="text-white/90 mb-4 text-sm md:text-base">
              رعايتك الصحية في مكان واحد. احجز مواعيدك، تابع صحتك، واستشر أطباءنا أينما كنت.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button
                onClick={() => setActiveTab('symptom-checker')}
                className="bg-white text-emerald-700 hover:bg-white/90 gap-2"
              >
                <Bot className="h-4 w-4" />
                ابدأ فحص الأعراض
              </Button>
              <Button
                onClick={() => setActiveTab('doctors')}
                variant="outline"
                className="bg-white/10 text-white border-white/30 hover:bg-white/20 hover:text-white gap-2"
              >
                <Stethoscope className="h-4 w-4" />
                تصفح الأطباء
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
        {statCards.map((stat) => {
          const Icon = stat.icon
          return (
            <Card key={stat.label} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4 md:p-5">
                <div className="flex items-center justify-between mb-2">
                  <div className={`p-2 rounded-lg bg-muted ${stat.color}`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  {loading ? (
                    <div className="h-4 w-12 bg-muted animate-pulse rounded" />
                  ) : null}
                </div>
                <div className="text-2xl md:text-3xl font-bold">{stat.value}</div>
                <div className="text-xs md:text-sm text-muted-foreground mt-1">{stat.label}</div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Quick actions */}
      <div>
        <h3 className="text-lg font-bold mb-3 flex items-center gap-2">
          <span>إجراءات سريعة</span>
        </h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
          {quickActions.map((action) => {
            const Icon = action.icon
            return (
              <Card
                key={action.label}
                className="cursor-pointer hover:shadow-md hover:border-primary/30 transition-all group"
                onClick={() => setActiveTab(action.tab)}
              >
                <CardContent className="p-4 md:p-5">
                  <div className={`inline-flex p-2.5 rounded-lg ${action.color} mb-3`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-sm">{action.label}</div>
                      <div className="text-xs text-muted-foreground mt-0.5">{action.desc}</div>
                    </div>
                    <ChevronLeft className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Upcoming appointments */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <div>
              <CardTitle className="flex items-center gap-2 text-base">
                <CalendarDays className="h-4 w-4 text-primary" />
                المواعيد القادمة
              </CardTitle>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setActiveTab('appointments')} className="text-xs">
              عرض الكل
            </Button>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-16 bg-muted animate-pulse rounded-lg" />
                ))}
              </div>
            ) : upcomingAppointments.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <CalendarDays className="h-10 w-10 mx-auto mb-2 opacity-30" />
                <p className="text-sm">لا توجد مواعيد قادمة</p>
                <Button variant="outline" size="sm" className="mt-3" onClick={() => setActiveTab('doctors')}>
                  احجز موعداً
                </Button>
              </div>
            ) : (
              <div className="space-y-3 max-h-96 overflow-y-auto custom-scrollbar">
                {upcomingAppointments.map((apt) => (
                  <div
                    key={apt.id}
                    className="flex items-center gap-3 p-3 rounded-lg border hover:bg-accent/50 transition-colors"
                  >
                    <div className="flex flex-col items-center justify-center w-14 h-14 rounded-lg bg-primary/10 text-primary shrink-0">
                      <span className="text-xs">{new Date(apt.date).toLocaleDateString('ar', { month: 'short' })}</span>
                      <span className="text-lg font-bold leading-none">{new Date(apt.date).getDate()}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm truncate">{apt.doctor.name}</div>
                      <div className="text-xs text-muted-foreground truncate">{apt.doctor.specialty}</div>
                      <div className="flex items-center gap-2 mt-1">
                        <Clock className="h-3 w-3 text-muted-foreground" />
                        <span className="text-xs text-muted-foreground">{apt.time}</span>
                        <Badge
                          variant={apt.status === 'مؤكد' ? 'default' : 'secondary'}
                          className="text-[10px] h-4"
                        >
                          {apt.status}
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Latest health metrics */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Activity className="h-4 w-4 text-primary" />
              آخر القياسات
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-3">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="h-12 bg-muted animate-pulse rounded-lg" />
                ))}
              </div>
            ) : latestMetrics.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Activity className="h-10 w-10 mx-auto mb-2 opacity-30" />
                <p className="text-sm">لا توجد قياسات</p>
              </div>
            ) : (
              <div className="space-y-2">
                {latestMetrics.map((m) => (
                  <div key={m.id} className="flex items-center justify-between p-2.5 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-md bg-primary/10 text-primary">
                        <TrendingUp className="h-3.5 w-3.5" />
                      </div>
                      <span className="text-xs text-muted-foreground">{m.type}</span>
                    </div>
                    <div className="text-left">
                      <span className="text-sm font-bold">{m.value}</span>
                      <span className="text-[10px] text-muted-foreground mr-1">{m.unit}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <Button variant="outline" size="sm" className="w-full mt-3" onClick={() => setActiveTab('metrics')}>
              عرض جميع القياسات
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Top doctors */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Award className="h-4 w-4 text-primary" />
            أفضل الأطباء
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={() => setActiveTab('doctors')} className="text-xs">
            عرض الكل
          </Button>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-40 bg-muted animate-pulse rounded-lg" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {doctors.map((doc) => (
                <Card
                  key={doc.id}
                  className="cursor-pointer hover:shadow-md hover:border-primary/30 transition-all"
                  onClick={() => setActiveTab('doctors')}
                >
                  <CardContent className="p-4 text-center">
                    <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-white text-xl font-bold">
                      {doc.name.charAt(2)}
                    </div>
                    <div className="font-medium text-sm truncate">{doc.name}</div>
                    <div className="text-xs text-muted-foreground mt-0.5 truncate">{doc.specialty}</div>
                    <div className="flex items-center justify-center gap-1 mt-2">
                      <span className="text-yellow-500 text-xs">★</span>
                      <span className="text-xs font-medium">{doc.rating}</span>
                      <span className="text-[10px] text-muted-foreground">({doc.reviews})</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
