'use client'

import { useEffect, useState } from 'react'
import { appointmentsApi, type Appointment } from '@/frontend/lib/api'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  CalendarDays,
  Clock,
  Plus,
  Trash2,
  CheckCircle2,
  XCircle,
  Stethoscope,
  Loader2,
  CalendarCheck,
} from 'lucide-react'
import { toast } from 'sonner'
import { useAppStore } from '@/frontend/stores/app-store'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { doctorsApi, type Doctor } from '@/frontend/lib/api'

const timeSlots = ['09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00', '17:00']

export function AppointmentsView() {
  const { setActiveTab, selectedDoctorId } = useAppStore()
  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [doctors, setDoctors] = useState<Doctor[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [form, setForm] = useState({
    doctorId: '',
    patientName: 'مريض',
    patientEmail: 'patient@medcare.com',
    patientPhone: '0501234567',
    date: new Date(Date.now() + 86400000).toISOString().split('T')[0],
    time: '10:00',
    type: 'استشارة',
    reason: '',
  })

  useEffect(() => {
    load()
  }, [])

  useEffect(() => {
    if (selectedDoctorId) {
      setForm((f) => ({ ...f, doctorId: selectedDoctorId }))
      setDialogOpen(true)
    }
  }, [selectedDoctorId])

  async function load() {
    setLoading(true)
    try {
      const [appts, docs] = await Promise.all([
        appointmentsApi.list(),
        doctorsApi.list(),
      ])
      setAppointments(appts.appointments)
      setDoctors(docs.doctors)
      if (!form.doctorId && docs.doctors.length > 0) {
        setForm((f) => ({ ...f, doctorId: docs.doctors[0].id }))
      }
    } catch (e) {
      console.error(e)
      toast.error('فشل تحميل المواعيد')
    } finally {
      setLoading(false)
    }
  }

  async function handleSubmit() {
    if (!form.doctorId || !form.patientName || !form.patientEmail || !form.date || !form.time) {
      toast.error('الرجاء ملء جميع الحقول المطلوبة')
      return
    }
    setSubmitting(true)
    try {
      await appointmentsApi.create(form)
      toast.success('تم حجز الموعد بنجاح')
      setDialogOpen(false)
      setForm((f) => ({ ...f, reason: '' }))
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'فشل حجز الموعد')
    } finally {
      setSubmitting(false)
    }
  }

  async function handleStatusChange(id: string, status: string) {
    try {
      await appointmentsApi.updateStatus(id, status)
      toast.success('تم تحديث حالة الموعد')
      await load()
    } catch (e) {
      toast.error('فشل تحديث الموعد')
    }
  }

  async function handleCancel(id: string) {
    try {
      await appointmentsApi.cancel(id)
      toast.success('تم إلغاء الموعد')
      await load()
    } catch (e) {
      toast.error('فشل إلغاء الموعد')
    }
  }

  const statusBadge = (status: string) => {
    const map: Record<string, { variant: 'default' | 'secondary' | 'destructive' | 'outline'; icon: typeof CheckCircle2 }> = {
      'مؤكد': { variant: 'default', icon: CheckCircle2 },
      'معلق': { variant: 'secondary', icon: Clock },
      'ملغي': { variant: 'destructive', icon: XCircle },
      'مكتمل': { variant: 'outline', icon: CheckCircle2 },
    }
    const cfg = map[status] || map['معلق']
    const Icon = cfg.icon
    return (
      <Badge variant={cfg.variant} className="gap-1">
        <Icon className="h-3 w-3" />
        {status}
      </Badge>
    )
  }

  return (
    <div className="space-y-6 animate-fade-in-up">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <CalendarDays className="h-6 w-6 text-primary" />
            مواعيدي الطبية
          </h2>
          <p className="text-sm text-muted-foreground mt-1">إدارة وحجز المواعيد الطبية</p>
        </div>
        <Button onClick={() => setDialogOpen(true)} className="gap-2">
          <Plus className="h-4 w-4" />
          حجز موعد جديد
        </Button>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardContent className="p-5">
                <div className="h-20 bg-muted animate-pulse rounded-lg" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : appointments.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <CalendarCheck className="h-12 w-12 mx-auto text-muted-foreground/30 mb-3" />
            <p className="text-muted-foreground mb-4">لا توجد مواعيد محجوزة</p>
            <Button onClick={() => setDialogOpen(true)} className="gap-2">
              <Plus className="h-4 w-4" />
              احجز أول موعد
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {appointments.map((apt) => (
            <Card key={apt.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4 md:p-5">
                <div className="flex items-start gap-4">
                  <div className="flex flex-col items-center justify-center w-16 h-16 rounded-xl bg-primary/10 text-primary shrink-0">
                    <span className="text-xs">{new Date(apt.date).toLocaleDateString('ar', { month: 'short' })}</span>
                    <span className="text-xl font-bold leading-none">{new Date(apt.date).getDate()}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 flex-wrap">
                      <div>
                        <div className="font-semibold flex items-center gap-2">
                          <Stethoscope className="h-4 w-4 text-primary" />
                          {apt.doctor.name}
                        </div>
                        <div className="text-sm text-muted-foreground mt-0.5">{apt.doctor.specialty}</div>
                      </div>
                      {statusBadge(apt.status)}
                    </div>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-3 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3.5 w-3.5" />
                        {apt.time}
                      </span>
                      <span className="flex items-center gap-1">
                        <CalendarDays className="h-3.5 w-3.5" />
                        {new Date(apt.date).toLocaleDateString('ar')}
                      </span>
                      <Badge variant="outline" className="text-xs">{apt.type}</Badge>
                      {apt.reason && (
                        <span className="text-xs truncate">السبب: {apt.reason}</span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 mt-3">
                      {apt.status === 'معلق' && (
                        <Button size="sm" variant="default" onClick={() => handleStatusChange(apt.id, 'مؤكد')} className="h-8 gap-1">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          تأكيد
                        </Button>
                      )}
                      {apt.status !== 'مكتمل' && apt.status !== 'ملغي' && (
                        <Button size="sm" variant="outline" onClick={() => handleStatusChange(apt.id, 'مكتمل')} className="h-8">
                          إكمال
                        </Button>
                      )}
                      {apt.status !== 'ملغي' && (
                        <Button size="sm" variant="ghost" onClick={() => handleCancel(apt.id)} className="h-8 text-destructive hover:text-destructive gap-1">
                          <Trash2 className="h-3.5 w-3.5" />
                          إلغاء
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Booking dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5 text-primary" />
              حجز موعد جديد
            </DialogTitle>
            <DialogDescription>
              املأ النموذج لحجز موعدك مع الطبيب
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 max-h-[60vh] overflow-y-auto custom-scrollbar pr-1">
            <div className="space-y-2">
              <Label>الطبيب *</Label>
              <Select value={form.doctorId} onValueChange={(v) => setForm({ ...form, doctorId: v })}>
                <SelectTrigger><SelectValue placeholder="اختر الطبيب" /></SelectTrigger>
                <SelectContent>
                  {doctors.map((d) => (
                    <SelectItem key={d.id} value={d.id} disabled={!d.available}>
                      {d.name} - {d.specialty} {!d.available && '(غير متاح)'}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>الاسم *</Label>
                <Input value={form.patientName} onChange={(e) => setForm({ ...form, patientName: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>البريد *</Label>
                <Input type="email" value={form.patientEmail} onChange={(e) => setForm({ ...form, patientEmail: e.target.value })} dir="ltr" />
              </div>
            </div>
            <div className="space-y-2">
              <Label>الهاتف</Label>
              <Input value={form.patientPhone} onChange={(e) => setForm({ ...form, patientPhone: e.target.value })} dir="ltr" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>التاريخ *</Label>
                <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>الوقت *</Label>
                <Select value={form.time} onValueChange={(v) => setForm({ ...form, time: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {timeSlots.map((t) => (
                      <SelectItem key={t} value={t}>{t}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>نوع الزيارة</Label>
              <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="استشارة">استشارة</SelectItem>
                  <SelectItem value="تطمين">تطمين</SelectItem>
                  <SelectItem value="متابعة">متابعة</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>سبب الزيارة</Label>
              <Textarea value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} rows={2} placeholder="صف الأعراض أو سبب الزيارة..." />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
            <Button onClick={handleSubmit} disabled={submitting} className="gap-2">
              {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
              تأكيد الحجز
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
