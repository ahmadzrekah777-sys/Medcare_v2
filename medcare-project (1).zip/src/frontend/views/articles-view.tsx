'use client'

import { useEffect, useState } from 'react'
import { articlesApi, type Article } from '@/frontend/lib/api'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Newspaper,
  Clock,
  User,
  ArrowLeft,
  Loader2,
  BookOpen,
  TrendingUp,
} from 'lucide-react'
import { toast } from 'sonner'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

export function ArticlesView() {
  const [articles, setArticles] = useState<Article[]>([])
  const [categories, setCategories] = useState<string[]>([])
  const [category, setCategory] = useState('all')
  const [loading, setLoading] = useState(true)
  const [viewArticle, setViewArticle] = useState<Article | null>(null)

  useEffect(() => {
    load()
  }, [category])

  async function load() {
    setLoading(true)
    try {
      const data = await articlesApi.list(category)
      setArticles(data.articles)
      setCategories(data.categories)
    } catch (e) {
      toast.error('فشل تحميل المقالات')
    } finally {
      setLoading(false)
    }
  }

  const featured = articles[0]
  const rest = articles.slice(1)

  return (
    <div className="space-y-6 animate-fade-in-up">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Newspaper className="h-6 w-6 text-primary" />
            مقالات صحية
          </h2>
          <p className="text-sm text-muted-foreground mt-1">مقالات ونصائح طبية من خبرائنا</p>
        </div>
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="التصنيف" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كل التصنيفات</SelectItem>
            {categories.map((c) => (
              <SelectItem key={c} value={c}>{c}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="space-y-6">
          <Card>
            <CardContent className="p-6">
              <div className="h-48 bg-muted animate-pulse rounded-lg" />
            </CardContent>
          </Card>
          <div className="grid md:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardContent className="p-5">
                  <div className="h-32 bg-muted animate-pulse rounded-lg" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      ) : articles.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Newspaper className="h-12 w-12 mx-auto text-muted-foreground/30 mb-3" />
            <p className="text-muted-foreground">لا توجد مقالات في هذا التصنيف</p>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Featured article */}
          {featured && (
            <Card
              className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow border-primary/20"
              onClick={() => setViewArticle(featured)}
            >
              <CardContent className="p-0">
                <div className="grid md:grid-cols-2 gap-0">
                  <div className="bg-gradient-to-br from-emerald-500 via-teal-500 to-cyan-500 p-8 md:p-10 text-white flex flex-col justify-center min-h-[200px]">
                    <Badge className="bg-white/20 text-white border-none w-fit mb-3">مقال مميز</Badge>
                    <h3 className="text-xl md:text-2xl font-bold mb-2 leading-tight">{featured.title}</h3>
                    <p className="text-white/90 text-sm line-clamp-3">{featured.excerpt}</p>
                    <div className="flex items-center gap-3 mt-4 text-xs text-white/80">
                      <span className="flex items-center gap-1">
                        <User className="h-3 w-3" />
                        {featured.author}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {featured.readTime} دقائق
                      </span>
                    </div>
                  </div>
                  <div className="p-6 md:p-8 flex flex-col justify-center">
                    <Badge variant="outline" className="w-fit mb-3">{featured.category}</Badge>
                    <p className="text-sm text-muted-foreground leading-relaxed line-clamp-4 mb-4">
                      {featured.excerpt}
                    </p>
                    <Button variant="outline" className="w-fit gap-2">
                      اقرأ المقال
                      <ArrowLeft className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Other articles */}
          {rest.length > 0 && (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {rest.map((article) => (
                <Card
                  key={article.id}
                  className="cursor-pointer hover:shadow-md hover:border-primary/30 transition-all group"
                  onClick={() => setViewArticle(article)}
                >
                  <CardContent className="p-5">
                    <div className="flex items-center justify-between mb-3">
                      <Badge variant="secondary" className="text-xs">{article.category}</Badge>
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {article.readTime} د
                      </span>
                    </div>
                    <h3 className="font-semibold text-sm leading-tight mb-2 group-hover:text-primary transition-colors line-clamp-2">
                      {article.title}
                    </h3>
                    <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{article.excerpt}</p>
                    <div className="flex items-center justify-between pt-3 border-t">
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <User className="h-3 w-3" />
                        {article.author}
                      </span>
                      <ArrowLeft className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </>
      )}

      {/* View dialog */}
      <Dialog open={!!viewArticle} onOpenChange={(o) => !o && setViewArticle(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-hidden flex flex-col">
          {viewArticle && (
            <>
              <DialogHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="secondary">{viewArticle.category}</Badge>
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {viewArticle.readTime} دقائق قراءة
                  </span>
                </div>
                <DialogTitle className="text-xl leading-tight">{viewArticle.title}</DialogTitle>
              </DialogHeader>
              <div className="flex items-center gap-2 pb-3 border-b">
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <User className="h-4 w-4" />
                </div>
                <div>
                  <div className="text-sm font-medium">{viewArticle.author}</div>
                  <div className="text-xs text-muted-foreground">
                    {new Date(viewArticle.createdAt).toLocaleDateString('ar')}
                  </div>
                </div>
              </div>
              <div className="overflow-y-auto custom-scrollbar flex-1 py-2">
                <p className="text-sm text-muted-foreground mb-4 leading-relaxed">{viewArticle.excerpt}</p>
                <div className="prose prose-sm max-w-none">
                  <p className="text-sm whitespace-pre-wrap leading-relaxed">{viewArticle.content}</p>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
