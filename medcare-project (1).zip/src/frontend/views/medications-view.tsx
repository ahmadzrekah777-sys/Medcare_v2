'use client'

import { useEffect, useState } from 'react'
import { medicationsApi, type Medication } from '@/frontend/lib/api'
import {
  Card,
  CardContent,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import {
  Pill,
  Plus,
  Trash2,
  Loader2,
  Clock,
  Calendar,
  FileText,
  CircleCheck,
  Circle,
  Bell,
} from 'lucide-react'
import { toast } from 'sonner'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'

export function MedicationsView() {
  const [medications, setMedications] = useState<Medication[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [form, setForm] = useState({
    name: '',
    dosage: '',
    frequency: '',
    startDate: new Date().toISOString().split('T')[0],
    endDate: '',
    notes: '',
  })

  useEffect(() => {
    load()
  }, [])

  async function load() {
    setLoading(true)
    try {
      const data = await medicationsApi.list()
      setMedications(data.medications)
    } catch (e) {
      toast.error('فشل تحميل الأدوية')
    } finally {
      setLoading(false)
    }
  }

  async function handleSubmit() {
    if (!form.name || !form.dosage || !form.frequency || !form.startDate) {
      toast.error('الرجاء ملء جميع الحقول المطلوبة')
      return
    }
    setSubmitting(true)
    try {
      await medicationsApi.create({
        ...form,
        endDate: form.endDate || undefined,
        notes: form.notes || undefined,
      })
      toast.success('تم إضافة الدواء بنجاح')
      setDialogOpen(false)
      setForm({ name: '', dosage: '', frequency: '', startDate: new Date().toISOString().split('T')[0], endDate: '', notes: '' })
      await load()
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'فشل إضافة الدواء')
    } finally {
      setSubmitting(false)
    }
  }

  async function handleToggle(id: string, active: boolean) {
    try {
      await medicationsApi.toggle(id, active)
      await load()
    } catch (e) {
      toast.error('فشل تحديث الدواء')
    }
  }

  async function handleDelete(id: string) {
    try {
      await medicationsApi.delete(id)
      toast.success('تم حذف الدواء')
      await load()
    } catch (e) {
      toast.error('فشل حذف الدواء')
    }
  }

  const activeMeds = medications.filter((m) => m.active)
  const inactiveMeds = medications.filter((m) => !m.active)

  const renderMed = (med: Medication) => (
    <Card key={med.id} className={`hover:shadow-md transition-shadow ${!med.active ? 'opacity-60' : ''}`}>
      <CardContent className="p-4 md:p-5">
        <div className="flex items-start gap-3">
          <div className={`p-2.5 rounded-lg shrink-0 ${med.active ? 'bg-emerald-500/10 text-emerald-600' : 'bg-muted text-muted-foreground'}`}>
            {med.active ? <CircleCheck className="h-5 w-5" /> : <Circle className="h-5 w-5" />}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div>
                <h3 className="font-semibold text-sm">{med.name}</h3>
                <div className="flex items-center gap-2 mt-0.5">
                  <Badge variant="secondary" className="text-xs">{med.dosage}</Badge>
                  <span className="text-xs text-muted-foreground">{med.frequency}</span>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <Switch checked={med.active} onCheckedChange={(c) => handleToggle(med.id, c)} />
                <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive" onClick={() => handleDelete(med.id)}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-3 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <Calendar className="h-3 w-3" />
                من {new Date(med.startDate).toLocaleDateString('ar')}
              </span>
              {med.endDate && (
                <span className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  إلى {new Date(med.endDate).toLocaleDateString('ar')}
                </span>
              )}
            </div>
            {med.notes && (
              <div className="flex items-start gap-1.5 mt-2 text-xs text-muted-foreground bg-muted/40 rounded p-2">
                <FileText className="h-3 w-3 mt-0.5 shrink-0" />
                <span>{med.notes}</span>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="space-y-6 animate-fade-in-up">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Pill className="h-6 w-6 text-primary" />
            الأدوية والتذكيرات
          </h2>
          <p className="text-sm text-muted-foreground mt-1">إدارة أدويتك وجداول الجرعات</p>
        </div>
        <Button onClick={() => setDialogOpen(true)} className="gap-2">
          <Plus className="h-4 w-4" />
          إضافة دواء
        </Button>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardContent className="p-5">
                <div className="h-16 bg-muted animate-pulse rounded-lg" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : medications.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Pill className="h-12 w-12 mx-auto text-muted-foreground/30 mb-3" />
            <p className="text-muted-foreground mb-4">لا توجد أدوية مسجلة</p>
            <Button onClick={() => setDialogOpen(true)} className="gap-2">
              <Plus className="h-4 w-4" />
              أضف دواءك الأول
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {activeMeds.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold text-muted-foreground mb-3 flex items-center gap-2">
                <Bell className="h-4 w-4 text-emerald-500" />
                الأدوية النشطة ({activeMeds.length})
              </h3>
              <div className="space-y-3 max-h-96 overflow-y-auto custom-scrollbar pl-1">
                {activeMeds.map(renderMed)}
              </div>
            </div>
          )}
          {inactiveMeds.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold text-muted-foreground mb-3">
                الأدوية المتوقفة ({inactiveMeds.length})
              </h3>
              <div className="space-y-3">
                {inactiveMeds.map(renderMed)}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Add dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5 text-primary" />
              إضافة دواء جديد
            </DialogTitle>
            <DialogDescription>سجل دواءك الجديد وحدد جدول الجرعات</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>اسم الدواء *</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="مثال: باراسيتامول" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>الجرعة *</Label>
                <Input value={form.dosage} onChange={(e) => setForm({ ...form, dosage: e.target.value })} placeholder="500mg" dir="ltr" />
              </div>
              <div className="space-y-2">
                <Label>التكرار *</Label>
                <Input value={form.frequency} onChange={(e) => setForm({ ...form, frequency: e.target.value })} placeholder="كل 8 ساعات" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>تاريخ البدء *</Label>
                <Input type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>تاريخ الانتهاء</Label>
                <Input type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} />
              </div>
            </div>
            <div className="space-y-2">
              <Label>ملاحظات</Label>
              <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={2} placeholder="مثال: بعد الأكل" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
            <Button onClick={handleSubmit} disabled={submitting} className="gap-2">
              {submitting && <Loader2 className="h-4 w-4 animate-spin" />}
              حفظ الدواء
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
