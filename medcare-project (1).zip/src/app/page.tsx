'use client'

import { useAppStore, type ViewTab } from '@/frontend/stores/app-store'
import {
  LayoutDashboard,
  Stethoscope,
  CalendarDays,
  Bot,
  Video,
  FileText,
  Activity,
  Pill,
  Newspaper,
  HeartPulse,
  Moon,
  Sun,
  Menu,
  X,
} from 'lucide-react'
import { useTheme } from 'next-themes'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { cn } from '@/lib/utils'
import { useEffect } from 'react'
import { useMounted } from '@/hooks/use-mounted'
import { toast } from 'sonner'
import { DashboardView } from '@/frontend/views/dashboard-view'
import { DoctorsView } from '@/frontend/views/doctors-view'
import { AppointmentsView } from '@/frontend/views/appointments-view'
import { SymptomCheckerView } from '@/frontend/views/symptom-checker-view'
import { TelemedicineView } from '@/frontend/views/telemedicine-view'
import { RecordsView } from '@/frontend/views/records-view'
import { MetricsView } from '@/frontend/views/metrics-view'
import { MedicationsView } from '@/frontend/views/medications-view'
import { ArticlesView } from '@/frontend/views/articles-view'

const navItems: Array<{ id: ViewTab; label: string; icon: typeof LayoutDashboard }> = [
  { id: 'dashboard', label: 'الرئيسية', icon: LayoutDashboard },
  { id: 'doctors', label: 'الأطباء', icon: Stethoscope },
  { id: 'appointments', label: 'المواعيد', icon: CalendarDays },
  { id: 'symptom-checker', label: 'فحص الأعراض', icon: Bot },
  { id: 'telemedicine', label: 'الطب عن بعد', icon: Video },
  { id: 'records', label: 'السجلات الطبية', icon: FileText },
  { id: 'metrics', label: 'القياسات الصحية', icon: Activity },
  { id: 'medications', label: 'الأدوية', icon: Pill },
  { id: 'articles', label: 'المقالات', icon: Newspaper },
]

function ThemeToggle() {
  const { theme, setTheme } = useTheme()
  const mounted = useMounted()
  if (!mounted) return <div className="h-9 w-9" />
  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
      aria-label="تبديل المظهر"
    >
      {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
    </Button>
  )
}

function NavContent({ onNavigate }: { onNavigate?: () => void }) {
  const { activeTab, setActiveTab } = useAppStore()
  return (
    <nav className="flex flex-col gap-1 px-3 py-2">
      {navItems.map((item) => {
        const Icon = item.icon
        const active = activeTab === item.id
        return (
          <button
            key={item.id}
            onClick={() => {
              setActiveTab(item.id)
              onNavigate?.()
            }}
            className={cn(
              'flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all',
              active
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground'
            )}
          >
            <Icon className="h-5 w-5 shrink-0" />
            <span>{item.label}</span>
          </button>
        )
      })}
    </nav>
  )
}

function Sidebar() {
  return (
    <aside className="hidden lg:flex w-64 shrink-0 flex-col border-l bg-sidebar/50 backdrop-blur">
      <div className="flex h-16 items-center gap-2 border-b px-6">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground">
          <HeartPulse className="h-5 w-5" />
        </div>
        <div className="flex flex-col">
          <span className="text-lg font-bold leading-tight">MedCare</span>
          <span className="text-[10px] text-muted-foreground">رعايتك الصحية في مكان واحد</span>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto custom-scrollbar">
        <NavContent />
      </div>
      <div className="border-t p-4">
        <div className="rounded-lg bg-primary/5 p-3 text-center">
          <p className="text-xs text-muted-foreground">طوارئ؟ اتصل بـ</p>
          <p className="text-sm font-bold text-primary" dir="ltr">911</p>
        </div>
      </div>
    </aside>
  )
}

function MobileNav() {
  const { sidebarOpen, setSidebarOpen } = useAppStore()
  return (
    <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
      <SheetContent side="right" className="w-72 p-0">
        <div className="flex h-16 items-center gap-2 border-b px-6">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <HeartPulse className="h-5 w-5" />
          </div>
          <span className="text-lg font-bold">MedCare</span>
        </div>
        <div className="overflow-y-auto custom-scrollbar">
          <NavContent onNavigate={() => setSidebarOpen(false)} />
        </div>
      </SheetContent>
    </Sheet>
  )
}

export default function Home() {
  const { activeTab, setSidebarOpen } = useAppStore()

  // Global error handler for unhandled promise rejections
  useEffect(() => {
    const handler = (e: PromiseRejectionEvent) => {
      console.error('Unhandled rejection:', e.reason)
      toast.error('حدث خطأ غير متوقع')
    }
    window.addEventListener('unhandledrejection', handler)
    return () => window.removeEventListener('unhandledrejection', handler)
  }, [])

  const renderView = () => {
    switch (activeTab) {
      case 'dashboard': return <DashboardView />
      case 'doctors': return <DoctorsView />
      case 'appointments': return <AppointmentsView />
      case 'symptom-checker': return <SymptomCheckerView />
      case 'telemedicine': return <TelemedicineView />
      case 'records': return <RecordsView />
      case 'metrics': return <MetricsView />
      case 'medications': return <MedicationsView />
      case 'articles': return <ArticlesView />
      default: return <DashboardView />
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <div className="flex flex-1">
        <Sidebar />

        <div className="flex flex-1 flex-col min-w-0">
          {/* Mobile header */}
          <header className="lg:hidden sticky top-0 z-40 flex h-14 items-center justify-between border-b bg-background/95 backdrop-blur px-4">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                <HeartPulse className="h-4 w-4" />
              </div>
              <span className="font-bold">MedCare</span>
            </div>
            <div className="flex items-center gap-1">
              <ThemeToggle />
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSidebarOpen(true)}
                aria-label="القائمة"
              >
                <Menu className="h-5 w-5" />
              </Button>
            </div>
          </header>

          {/* Desktop header */}
          <header className="hidden lg:flex sticky top-0 z-40 h-16 items-center justify-between border-b bg-background/95 backdrop-blur px-6">
            <div>
              <h1 className="text-lg font-bold">
                {navItems.find((n) => n.id === activeTab)?.label}
              </h1>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" className="gap-2" onClick={() => useAppStore.getState().setActiveTab('symptom-checker')}>
                <Bot className="h-4 w-4" />
                <span className="hidden sm:inline">المساعد الطبي</span>
              </Button>
              <ThemeToggle />
              <div className="flex items-center gap-2 pr-2 border-r">
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-primary font-bold">
                  م
                </div>
                <div className="hidden md:flex flex-col">
                  <span className="text-sm font-medium">مرحباً</span>
                  <span className="text-xs text-muted-foreground">مريض</span>
                </div>
              </div>
            </div>
          </header>

          {/* Main content */}
          <main className="flex-1 p-4 md:p-6 lg:p-8 overflow-x-hidden">
            <div className="mx-auto max-w-7xl animate-fade-in-up" key={activeTab}>
              {renderView()}
            </div>
          </main>

          {/* Sticky footer */}
          <footer className="mt-auto border-t bg-card">
            <div className="mx-auto max-w-7xl px-4 py-6 md:px-8">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                    <HeartPulse className="h-4 w-4" />
                  </div>
                  <span className="text-sm font-bold">MedCare</span>
                  <span className="text-xs text-muted-foreground">© 2025 جميع الحقوق محفوظة</span>
                </div>
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <span>منصة طبية تفاعلية متقدمة</span>
                  <span className="flex items-center gap-1">
                    <span className="h-2 w-2 rounded-full bg-green-500 animate-medical-pulse" />
                    الخدمة تعمل
                  </span>
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>

      <MobileNav />
    </div>
  )
}
