import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/chat - Get chat message history for a room
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const roomId = searchParams.get('roomId')

    if (!roomId) {
      return NextResponse.json({ error: 'معرف الغرفة مطلوب' }, { status: 400 })
    }

    const messages = await db.chatMessage.findMany({
      where: { roomId },
      orderBy: { createdAt: 'asc' },
    })

    return NextResponse.json({ messages })
  } catch (error) {
    console.error('GET /api/chat error:', error)
    return NextResponse.json({ error: 'فشل في تحميل الرسائل' }, { status: 500 })
  }
}

// POST /api/chat - Save a chat message (fallback for non-realtime)
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { roomId, sender, senderName, content, type } = body

    if (!roomId || !sender || !content) {
      return NextResponse.json(
        { error: 'الرجاء ملء جميع الحقول المطلوبة' },
        { status: 400 }
      )
    }

    const message = await db.chatMessage.create({
      data: {
        roomId,
        sender,
        senderName: senderName || sender,
        content,
        type: type || 'user',
      },
    })

    return NextResponse.json({ message }, { status: 201 })
  } catch (error) {
    console.error('POST /api/chat error:', error)
    return NextResponse.json({ error: 'فشل في حفظ الرسالة' }, { status: 500 })
  }
}
