import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/records - List medical records
export async function GET() {
  try {
    const records = await db.medicalRecord.findMany({
      orderBy: { date: 'desc' },
    })
    return NextResponse.json({ records })
  } catch (error) {
    console.error('GET /api/records error:', error)
    return NextResponse.json(
      { error: 'فشل في تحميل السجلات الطبية' },
      { status: 500 }
    )
  }
}

// POST /api/records - Create medical record
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { patientName, title, type, date, doctorName, description } = body

    if (!title || !type || !date || !description) {
      return NextResponse.json(
        { error: 'الرجاء ملء جميع الحقول المطلوبة' },
        { status: 400 }
      )
    }

    const record = await db.medicalRecord.create({
      data: {
        patientName: patientName || 'مريض',
        title,
        type,
        date: new Date(date),
        doctorName: doctorName || null,
        description,
      },
    })

    return NextResponse.json({ record }, { status: 201 })
  } catch (error) {
    console.error('POST /api/records error:', error)
    return NextResponse.json(
      { error: 'فشل في إضافة السجل الطبي' },
      { status: 500 }
    )
  }
}

// DELETE /api/records - Delete medical record
export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'معرف السجل مطلوب' }, { status: 400 })
    }

    await db.medicalRecord.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('DELETE /api/records error:', error)
    return NextResponse.json(
      { error: 'فشل في حذف السجل الطبي' },
      { status: 500 }
    )
  }
}
