import { NextRequest, NextResponse } from 'next/server'

// ============================================================
// إعدادات Ollama - عدّل هذه القيم حسب إعداداتك
// ============================================================

// اسم النموذج المثبت في Ollama (غيّره حسب ما تملك)
// شائع: llama3.2, llama3.1, qwen2.5, mistral, phi3
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'llama3.2'

// عنوان خادم Ollama (الافتراضي: localhost:11434)
// إذا كان Ollama على جهاز آخر، ضع IP ذلك الجهاز
const OLLAMA_URL = process.env.OLLAMA_URL || 'http://127.0.0.1:11434'

// ============================================================

const SYSTEM_PROMPT = `أنت مساعد طبي ذكي ومحترف اسمه "طبيبك" يعمل في منصة MedCare الطبية. دورك هو مساعدة المرضى في فهم أعراضهم وتوجيههم بشكل صحيح.

مهم جداً - اتبع هذه القواعد بدقة:
1. أنت لست بديلاً عن الطبيب. دائماً ذكر المريض بضرورة استشارة طبيب مختص للتشخيص النهائي.
2. لا تصف أدوية محددة أو جرعات. يمكنك ذكر أنواع عامة من العلاجات المنزلية فقط.
3. اطلب تفاصيل أكثر عن الأعراض عندما يكون الوصف غامضاً (مدة الأعراض، شدتها، موقع الألم).
4. اقترح التخصص الطبي المناسب للمريض بناءً على الأعراض.
5. قيّم مستوى الخطورة: منخفض (يمكن الانتظار)، متوسط (مراجعة قريبة)، عالي (طوارئ فورية).
6. كن موجزاً وواضحاً، استخدم اللغة العربية الفصحى المبسطة.
7. تعامل مع الحالات الطارئة بجدية - إذا كانت الأعراض تشير إلى حالة طارئة (ألم صدر شديد، صعوبة تنفس، فقدان وعي، نزيف شديد) فأخبر المريض بطلب الإسعاف فوراً.

صيغة الرد:
- تحليل الأعراض: وصف موجز لما قد تشير إليه الأعراض
- التخصص المناسب: التخصص الطبي المقترح
- مستوى الخطورة: منخفض/متوسط/عالٍ مع توضيح
- نصائح عامة: 2-3 نصائح عملية
- تنبيه: تذكير بزيارة الطبيب

كن ودوداً ومطمئناً ومهنياً. اجعل ردك موجزاً وغير طويل.`

// واجهة رسالة Ollama
interface OllamaMessage {
  role: 'system' | 'user' | 'assistant'
  content: string
}

// دالة تنظيف الرد من وسوم التفكير (qwen3 thinking mode) والوسوم المزعجة
function cleanResponse(text: string): string {
  let cleaned = text

  // إزالة كتل التفكير <think>...</think> (qwen3 / deepseek)
  cleaned = cleaned.replace(/<think>[\s\S]*?<\/think>/gi, '')
  // إزالة كتل <thinking>...</thinking>
  cleaned = cleaned.replace(/<thinking>[\s\S]*?<\/thinking>/gi, '')
  // إزالة أي وسم متبقي
  cleaned = cleaned.replace(/<\/?(think|thinking|reflection)[^>]*>/gi, '')
  // إزالة أكواد JSON/HTML الخام إذا ظهرت
  cleaned = cleaned.replace(/```json\s*/gi, '').replace(/```\s*/g, '')
  // إزالة المسافات الزائدة في البداية والنهاية
  cleaned = cleaned.trim()

  return cleaned
}

// دالة استدعاء Ollama
async function callOllama(messages: OllamaMessage[]): Promise<string> {
  const response = await fetch(`${OLLAMA_URL}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: OLLAMA_MODEL,
      messages: messages,
      stream: false, // نريد الرد كاملاً دفعة واحدة
      options: {
        temperature: 0.7, // توازن بين الإبداع والدقة
        top_p: 0.9,
      },
    }),
  })

  if (!response.ok) {
    const errorText = await response.text()
    throw new Error(`Ollama error (${response.status}): ${errorText}`)
  }

  const data = await response.json()
  const rawContent = data.message?.content || ''
  // تنظيف الرد من وسوم التفكير الخاصة بـ qwen3
  return cleanResponse(rawContent)
}

// التحقق من اتصال Ollama
export async function GET() {
  try {
    const response = await fetch(`${OLLAMA_URL}/api/tags`, {
      method: 'GET',
    })
    if (response.ok) {
      const data = await response.json()
      const models = data.models?.map((m: { name: string }) => m.name) || []
      return NextResponse.json({
        status: 'connected',
        url: OLLAMA_URL,
        model: OLLAMA_MODEL,
        availableModels: models,
        message: `Ollama متصل. النموذج الحالي: ${OLLAMA_MODEL}`,
      })
    }
    throw new Error('فشل الاتصال بـ Ollama')
  } catch (error) {
    return NextResponse.json(
      {
        status: 'disconnected',
        url: OLLAMA_URL,
        model: OLLAMA_MODEL,
        error: error instanceof Error ? error.message : 'Unknown error',
        message: `تعذر الاتصال بـ Ollama على ${OLLAMA_URL}. تأكد من تشغيل Ollama.`,
      },
      { status: 503 }
    )
  }
}

// POST /api/symptom-checker - AI-powered symptom analysis via Ollama
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { message, history } = body

    if (!message || typeof message !== 'string') {
      return NextResponse.json(
        { error: 'الرجاء إدخال رسالة صحيحة' },
        { status: 400 }
      )
    }

    // بناء سلسلة المحادثة
    const messages: OllamaMessage[] = [
      { role: 'system', content: SYSTEM_PROMPT },
    ]

    // إضافة تاريخ المحادثة
    if (Array.isArray(history)) {
      for (const h of history.slice(-10)) {
        if (h.role && h.content) {
          // Ollama يقبل: system, user, assistant فقط
          const role: 'user' | 'assistant' = h.role === 'assistant' ? 'assistant' : 'user'
          messages.push({ role, content: h.content })
        }
      }
    }

    // إضافة رسالة المستخدم الحالية
    messages.push({ role: 'user', content: message })

    // استدعاء Ollama
    const response = await callOllama(messages)

    if (!response || response.trim().length === 0) {
      return NextResponse.json(
        { error: 'لم أتمكن من تحليل الأعراض، حاول مرة أخرى' },
        { status: 500 }
      )
    }

    return NextResponse.json({ response, message })
  } catch (error) {
    console.error('POST /api/symptom-checker error:', error)
    const errorMessage = error instanceof Error ? error.message : 'Unknown error'

    // رسائل خطأ ودية بالعربية
    let friendlyError = 'حدث خطأ في معالجة طلبك'
    if (errorMessage.includes('fetch') || errorMessage.includes('ECONNREFUSED')) {
      friendlyError = `تعذر الاتصال بـ Ollama. تأكد من تشغيل Ollama على ${OLLAMA_URL}. شغّل الأمر: ollama serve`
    } else if (errorMessage.includes('model')) {
      friendlyError = `النموذج "${OLLAMA_MODEL}" غير متاح في Ollama. شغّل: ollama pull ${OLLAMA_MODEL}`
    }

    return NextResponse.json(
      { error: friendlyError, detail: errorMessage },
      { status: 500 }
    )
  }
}
