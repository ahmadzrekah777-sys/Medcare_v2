import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/metrics - List health metrics
export async function GET() {
  try {
    const metrics = await db.healthMetric.findMany({
      orderBy: { recordedAt: 'desc' },
    })
    return NextResponse.json({ metrics })
  } catch (error) {
    console.error('GET /api/metrics error:', error)
    return NextResponse.json(
      { error: 'فشل في تحميل القياسات الصحية' },
      { status: 500 }
    )
  }
}

// POST /api/metrics - Create health metric
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { patientName, type, value, unit, recordedAt, notes } = body

    if (!type || !value || !unit) {
      return NextResponse.json(
        { error: 'الرجاء ملء جميع الحقول المطلوبة' },
        { status: 400 }
      )
    }

    const metric = await db.healthMetric.create({
      data: {
        patientName: patientName || 'مريض',
        type,
        value,
        unit,
        recordedAt: recordedAt ? new Date(recordedAt) : new Date(),
        notes: notes || null,
      },
    })

    return NextResponse.json({ metric }, { status: 201 })
  } catch (error) {
    console.error('POST /api/metrics error:', error)
    return NextResponse.json(
      { error: 'فشل في إضافة القياس الصحي' },
      { status: 500 }
    )
  }
}
