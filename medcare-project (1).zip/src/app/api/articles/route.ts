import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/articles - List articles
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const category = searchParams.get('category')

    const where: Record<string, unknown> = { published: true }
    if (category && category !== 'all') {
      where.category = category
    }

    const articles = await db.article.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    })

    const allArticles = await db.article.findMany({ where: { published: true } })
    const categories = [...new Set(allArticles.map((a) => a.category))]

    return NextResponse.json({ articles, categories })
  } catch (error) {
    console.error('GET /api/articles error:', error)
    return NextResponse.json(
      { error: 'فشل في تحميل المقالات' },
      { status: 500 }
    )
  }
}
