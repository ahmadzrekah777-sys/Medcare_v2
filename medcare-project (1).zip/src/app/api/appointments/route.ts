import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/appointments - List all appointments
export async function GET() {
  try {
    const appointments = await db.appointment.findMany({
      include: { doctor: true },
      orderBy: { date: 'asc' },
    })
    return NextResponse.json({ appointments })
  } catch (error) {
    console.error('GET /api/appointments error:', error)
    return NextResponse.json(
      { error: 'فشل في تحميل المواعيد' },
      { status: 500 }
    )
  }
}

// POST /api/appointments - Create new appointment
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { doctorId, patientName, patientEmail, patientPhone, date, time, type, reason } = body

    if (!doctorId || !patientName || !patientEmail || !date || !time) {
      return NextResponse.json(
        { error: 'الرجاء ملء جميع الحقول المطلوبة' },
        { status: 400 }
      )
    }

    const appointment = await db.appointment.create({
      data: {
        doctorId,
        patientName,
        patientEmail,
        patientPhone: patientPhone || null,
        date: new Date(date),
        time,
        type: type || 'استشارة',
        status: 'معلق',
        reason: reason || null,
      },
      include: { doctor: true },
    })

    return NextResponse.json({ appointment }, { status: 201 })
  } catch (error) {
    console.error('POST /api/appointments error:', error)
    return NextResponse.json(
      { error: 'فشل في حجز الموعد' },
      { status: 500 }
    )
  }
}

// PATCH /api/appointments - Update appointment status
export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json()
    const { id, status } = body

    if (!id || !status) {
      return NextResponse.json(
        { error: 'معرف الموعد والحالة مطلوبان' },
        { status: 400 }
      )
    }

    const appointment = await db.appointment.update({
      where: { id },
      data: { status },
      include: { doctor: true },
    })

    return NextResponse.json({ appointment })
  } catch (error) {
    console.error('PATCH /api/appointments error:', error)
    return NextResponse.json(
      { error: 'فشل في تحديث الموعد' },
      { status: 500 }
    )
  }
}

// DELETE /api/appointments - Cancel appointment
export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json(
        { error: 'معرف الموعد مطلوب' },
        { status: 400 }
      )
    }

    await db.appointment.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('DELETE /api/appointments error:', error)
    return NextResponse.json(
      { error: 'فشل في إلغاء الموعد' },
      { status: 500 }
    )
  }
}
