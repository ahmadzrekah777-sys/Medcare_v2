import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/medications - List medications
export async function GET() {
  try {
    const medications = await db.medication.findMany({
      orderBy: { startDate: 'desc' },
    })
    return NextResponse.json({ medications })
  } catch (error) {
    console.error('GET /api/medications error:', error)
    return NextResponse.json(
      { error: 'فشل في تحميل الأدوية' },
      { status: 500 }
    )
  }
}

// POST /api/medications - Create medication
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { patientName, name, dosage, frequency, startDate, endDate, notes } = body

    if (!name || !dosage || !frequency || !startDate) {
      return NextResponse.json(
        { error: 'الرجاء ملء جميع الحقول المطلوبة' },
        { status: 400 }
      )
    }

    const medication = await db.medication.create({
      data: {
        patientName: patientName || 'مريض',
        name,
        dosage,
        frequency,
        startDate: new Date(startDate),
        endDate: endDate ? new Date(endDate) : null,
        notes: notes || null,
        active: true,
      },
    })

    return NextResponse.json({ medication }, { status: 201 })
  } catch (error) {
    console.error('POST /api/medications error:', error)
    return NextResponse.json(
      { error: 'فشل في إضافة الدواء' },
      { status: 500 }
    )
  }
}

// PATCH /api/medications - Update medication (toggle active)
export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json()
    const { id, active } = body

    if (!id) {
      return NextResponse.json({ error: 'معرف الدواء مطلوب' }, { status: 400 })
    }

    const medication = await db.medication.update({
      where: { id },
      data: { active: active !== undefined ? active : undefined },
    })

    return NextResponse.json({ medication })
  } catch (error) {
    console.error('PATCH /api/medications error:', error)
    return NextResponse.json(
      { error: 'فشل في تحديث الدواء' },
      { status: 500 }
    )
  }
}

// DELETE /api/medications - Delete medication
export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'معرف الدواء مطلوب' }, { status: 400 })
    }

    await db.medication.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('DELETE /api/medications error:', error)
    return NextResponse.json(
      { error: 'فشل في حذف الدواء' },
      { status: 500 }
    )
  }
}
