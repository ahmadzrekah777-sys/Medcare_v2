import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/doctors - List doctors with optional filters
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const specialty = searchParams.get('specialty')
    const search = searchParams.get('search')
    const availableOnly = searchParams.get('available') === 'true'

    const where: Record<string, unknown> = {}
    if (specialty && specialty !== 'all') {
      where.specialty = specialty
    }
    if (availableOnly) {
      where.available = true
    }
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { specialty: { contains: search } },
        { subSpecialty: { contains: search } },
        { hospital: { contains: search } },
      ]
    }

    const doctors = await db.doctor.findMany({
      where,
      orderBy: { rating: 'desc' },
    })

    const allDoctors = await db.doctor.findMany()
    const specialties = [...new Set(allDoctors.map((d) => d.specialty))]

    return NextResponse.json({ doctors, specialties })
  } catch (error) {
    console.error('GET /api/doctors error:', error)
    return NextResponse.json(
      { error: 'فشل في تحميل بيانات الأطباء' },
      { status: 500 }
    )
  }
}
