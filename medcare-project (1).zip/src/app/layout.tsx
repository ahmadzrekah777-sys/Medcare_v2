import type { Metadata } from "next";
import { Cairo, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/frontend/components/theme-provider";

const cairo = Cairo({
  variable: "--font-geist-sans",
  subsets: ["arabic", "latin"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "MedCare - منصة طبية تفاعلية متقدمة",
  description: "منصة طبية تفاعلية متقدمة: حجز المواعيد، فحص الأعراض بالذكاء الاصطناعي، الطب عن بعد، السجلات الطبية، ومتابعة الصحة.",
  keywords: ["طبي", "مواعيد", "أطباء", "صحة", "ذكاء اصطناعي", "طب عن بعد", "MedCare"],
  authors: [{ name: "MedCare Team" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "MedCare - منصة طبية تفاعلية متقدمة",
    description: "رعايتك الصحية في مكان واحد",
    siteName: "MedCare",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body
        className={`${cairo.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
          <SonnerToaster position="top-center" richColors />
        </ThemeProvider>
      </body>
    </html>
  );
}
