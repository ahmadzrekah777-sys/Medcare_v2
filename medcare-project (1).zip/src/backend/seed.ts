import { db } from '@/lib/db'

// Seed data for MedCare Advanced Medical Platform
const doctors = [
  {
    name: 'د. سارة الأحمد',
    specialty: 'طب القلب',
    subSpecialty: 'أمراض القلب التداخلية',
    bio: 'استشارية أمراض القلب والأوعية الدموية مع خبرة 15 عاماً في علاج أمراض القلب المعقدة.',
    rating: 4.9,
    reviews: 328,
    experience: 15,
    fee: 500,
    available: true,
    hospital: 'مستشفى الملك فهد التخصصي',
    languages: 'العربية، الإنجليزية',
    location: 'الرياض',
  },
  {
    name: 'د. محمد العلي',
    specialty: 'الأطفال',
    subSpecialty: 'حديثي الولادة',
    bio: 'أخصائي طب الأطفال وحديثي الولادة، متخصص في رعاية الأطفال الخدج والأمراض المزمنة.',
    rating: 4.8,
    reviews: 215,
    experience: 12,
    fee: 350,
    available: true,
    hospital: 'مستشفى الأطفال',
    languages: 'العربية، الإنجليزية، الفرنسية',
    location: 'جدة',
  },
  {
    name: 'د. فاطمة الزهراء',
    specialty: 'النساء والولادة',
    subSpecialty: 'علاج العقم',
    bio: 'استشارية النساء والولادة والعقم، تساعد العائلات على تحقيق حلم الإنجاب.',
    rating: 4.9,
    reviews: 412,
    experience: 18,
    fee: 600,
    available: true,
    hospital: 'مستشفى الحياة للنساء',
    languages: 'العربية، الإنجليزية',
    location: 'الرياض',
  },
  {
    name: 'د. خالد المنصور',
    specialty: 'العظام',
    subSpecialty: 'جراحة المفاصل',
    bio: 'استشاري جراحة العظام والمفاصل، خبير في العمليات المنظارية واستبدال المفاصل.',
    rating: 4.7,
    reviews: 189,
    experience: 14,
    fee: 450,
    available: true,
    hospital: 'مستشفى الصحة التخصصي',
    languages: 'العربية، الإنجليزية',
    location: 'الدمام',
  },
  {
    name: 'د. نورا السالم',
    specialty: 'الجلدية',
    subSpecialty: 'الليزر والتجميل',
    bio: 'أخصائية الأمراض الجلدية والتجميل، متخصصة في علاج مشاكل البشرة والليزر.',
    rating: 4.8,
    reviews: 276,
    experience: 10,
    fee: 400,
    available: true,
    hospital: 'مركز الجمال الطبي',
    languages: 'العربية، الإنجليزية',
    location: 'الرياض',
  },
  {
    name: 'د. عبدالله الحربي',
    specialty: 'الباطنة',
    subSpecialty: 'الجهاز الهضمي',
    bio: 'استشاري الباطنة والجهاز الهضمي، متخصص في تنظير المعدة والقولون.',
    rating: 4.6,
    reviews: 143,
    experience: 16,
    fee: 420,
    available: false,
    hospital: 'مستشفى السلام',
    languages: 'العربية، الإنجليزية',
    location: 'الرياض',
  },
  {
    name: 'د. ليان القحطاني',
    specialty: 'العيون',
    subSpecialty: 'شبكية العين',
    bio: 'استشارية طب وجراحة العيون، متخصصة في أمراض الشبكية والمايكولا.',
    rating: 4.9,
    reviews: 198,
    experience: 13,
    fee: 480,
    available: true,
    hospital: 'مستشفى النور للعيون',
    languages: 'العربية، الإنجليزية',
    location: 'جدة',
  },
  {
    name: 'د. يوسف الشمري',
    specialty: 'المخ والأعصاب',
    subSpecialty: 'الصرع',
    bio: 'استشاري طب المخ والأعصاب، متخصص في علاج الصرع والصداع النصفي.',
    rating: 4.7,
    reviews: 167,
    experience: 17,
    fee: 550,
    available: true,
    hospital: 'مستشفى الأمل',
    languages: 'العربية، الإنجليزية، الألمانية',
    location: 'الرياض',
  },
]

const articles = [
  {
    title: '10 نصائح للحفاظ على صحة القلب',
    category: 'صحة القلب',
    excerpt: 'تعرف على أهم النصائح اليومية للحفاظ على صحة قلبك والوقاية من أمراض القلب.',
    content: 'صحة القلب من أهم جوانب الصحة العامة. إليك أهم النصائح:\n\n1. ممارسة الرياضة بانتظام لمدة 30 دقيقة يومياً\n2. تناول الأطعمة الغنية بأوميغا 3\n3. تجنب الدهون المشبعة\n4. الإقلاع عن التدخين\n5. التحكم في ضغط الدم\n6. الحفاظ على وزن صحي\n7. تقليل التوتر\n8. النوم الكافي 7-8 ساعات\n9. الفحص الدوري\n10. شرب الماء بكميات كافية',
    author: 'د. سارة الأحمد',
    readTime: 5,
  },
  {
    title: 'أهمية الفحص الطبي الدوري',
    category: 'الوقاية',
    excerpt: 'لماذا يجب عليك إجراء الفحص الطبي الدوري وما هي الفحوصات المهمة لكل عمر.',
    content: 'الفحص الطبي الدوري هو مفتاح الوقاية من الأمراض. يساعد في الكشف المبكر عن المشاكل الصحية قبل تفاقمها.\n\nفحوصات مهمة:\n- قياس ضغط الدم\n- فحص السكر\n- فحص الكوليسترول\n- فحص وظائف الكبد والكلى\n- فحص السرطان حسب العمر',
    author: 'د. عبدالله الحربي',
    readTime: 7,
  },
  {
    title: 'كيف تقوي جهازك المناعي طبيعياً',
    category: 'المناعة',
    excerpt: 'طرق طبيعية وفعالة لتعزيز جهازك المناعي والحماية من الأمراض الموسمية.',
    content: 'الجهاز المناعي القوي هو خط الدفاع الأول ضد الأمراض. إليك طرق تعزيزه:\n\n1. التغذية السليمة - فيتامين C، Zink\n2. النوم الجيد\n3. الرياضة المعتدلة\n4. تقليل التوتر\n5. شرب الماء\n6. التعرض للشمس لفيتامين D',
    author: 'د. محمد العلي',
    readTime: 6,
  },
  {
    title: 'الصحة النفسية في العصر الحديث',
    category: 'الصحة النفسية',
    excerpt: 'كيفية الحفاظ على صحتك النفسية في ظل ضغوط الحياة اليومية.',
    content: 'الصحة النفسية لا تقل أهمية عن الصحة الجسدية. من المهم الاهتمام بها:\n\n- ممارسة التأمل واليوجا\n- الحفاظ على العلاقات الاجتماعية\n- طلب المساعدة عند الحاجة\n- تخصيص وقت للهوايات\n- الابتعاد عن السلبية',
    author: 'د. يوسف الشمري',
    readTime: 8,
  },
]

const medications = [
  {
    patientName: 'مريض',
    name: 'أموكسيسيلين',
    dosage: '500mg',
    frequency: 'كل 8 ساعات',
    startDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    endDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
    notes: 'بعد الأكل',
    active: true,
  },
  {
    patientName: 'مريض',
    name: 'باراسيتامول',
    dosage: '1000mg',
    frequency: 'كل 6 ساعات عند الحاجة',
    startDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    endDate: null,
    notes: 'لتخفيف الألم والحرارة',
    active: true,
  },
  {
    patientName: 'مريض',
    name: 'فيتامين د',
    dosage: '1000 IU',
    frequency: 'يومياً',
    startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
    endDate: null,
    notes: 'مع الطعام',
    active: true,
  },
]

const healthMetrics = [
  { patientName: 'مريض', type: 'ضغط الدم', value: '120/80', unit: 'mmHg', recordedAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000) },
  { patientName: 'مريض', type: 'ضغط الدم', value: '118/76', unit: 'mmHg', recordedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000) },
  { patientName: 'مريض', type: 'ضغط الدم', value: '122/82', unit: 'mmHg', recordedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000) },
  { patientName: 'مريض', type: 'ضغط الدم', value: '119/78', unit: 'mmHg', recordedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000) },
  { patientName: 'مريض', type: 'ضغط الدم', value: '121/80', unit: 'mmHg', recordedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000) },
  { patientName: 'مريض', type: 'ضغط الدم', value: '120/79', unit: 'mmHg', recordedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000) },
  { patientName: 'مريض', type: 'معدل ضربات القلب', value: '72', unit: 'bpm', recordedAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000) },
  { patientName: 'مريض', type: 'معدل ضربات القلب', value: '68', unit: 'bpm', recordedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000) },
  { patientName: 'مريض', type: 'معدل ضربات القلب', value: '75', unit: 'bpm', recordedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000) },
  { patientName: 'مريض', type: 'معدل ضربات القلب', value: '70', unit: 'bpm', recordedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000) },
  { patientName: 'مريض', type: 'معدل ضربات القلب', value: '73', unit: 'bpm', recordedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000) },
  { patientName: 'مريض', type: 'معدل ضربات القلب', value: '71', unit: 'bpm', recordedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000) },
  { patientName: 'مريض', type: 'السكر', value: '95', unit: 'mg/dL', recordedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000) },
  { patientName: 'مريض', type: 'السكر', value: '102', unit: 'mg/dL', recordedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000) },
  { patientName: 'مريض', type: 'السكر', value: '98', unit: 'mg/dL', recordedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000) },
  { patientName: 'مريض', type: 'الوزن', value: '75.2', unit: 'kg', recordedAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000) },
  { patientName: 'مريض', type: 'الوزن', value: '74.8', unit: 'kg', recordedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000) },
  { patientName: 'مريض', type: 'الوزن', value: '74.5', unit: 'kg', recordedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000) },
  { patientName: 'مريض', type: 'الوزن', value: '74.1', unit: 'kg', recordedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000) },
]

const medicalRecords = [
  {
    patientName: 'مريض',
    title: 'تقرير فحص الدم الشامل',
    type: 'تحليل مخبري',
    date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    doctorName: 'د. عبدالله الحربي',
    description: 'نتائج طبيعية، مستوى الهيموغلوبين ضمن المعدل الطبيعي. عدد كريات الدم البيضاء طبيعي.',
  },
  {
    patientName: 'مريض',
    title: 'تخطيط القلب الكهربائي ECG',
    type: 'تشخيص',
    date: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
    doctorName: 'د. سارة الأحمد',
    description: 'تخطيط القلب طبيعي، معدل ضربات القلب منتظم 72 نبضة في الدقيقة.',
  },
  {
    patientName: 'مريض',
    title: 'وصفة دواء أموكسيسيلين',
    type: 'وصفة طبية',
    date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    doctorName: 'د. محمد العلي',
    description: 'مضاد حيوي لمدة 7 أيام لعلاج التهاب الجهاز التنفسي.',
  },
  {
    patientName: 'مريض',
    title: 'أشعة سينية للصدر',
    type: 'أشعة',
    date: new Date(Date.now() - 21 * 24 * 60 * 60 * 1000),
    doctorName: 'د. عبدالله الحربي',
    description: 'الرئتان سليمتان، لا توجد علامات للالتهاب أو السرطان.',
  },
  {
    patientName: 'مريض',
    title: 'تحليل سكر الصائم',
    type: 'تحليل مخبري',
    date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    doctorName: 'د. عبدالله الحربي',
    description: 'مستوى السكر 98 mg/dL، ضمن المعدل الطبيعي.',
  },
]

const appointments = [
  {
    patientName: 'مريض',
    patientEmail: 'patient@medcare.com',
    patientPhone: '0501234567',
    date: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
    time: '10:00',
    type: 'استشارة',
    status: 'مؤكد',
    reason: 'متابعة حالة القلب',
  },
  {
    patientName: 'مريض',
    patientEmail: 'patient@medcare.com',
    patientPhone: '0501234567',
    date: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
    time: '14:30',
    type: 'تطمين',
    status: 'معلق',
    reason: 'مراجعة نتائج التحاليل',
  },
]

async function main() {
  console.log('🌱 Seeding database...')

  await db.chatMessage.deleteMany()
  await db.appointment.deleteMany()
  await db.medicalRecord.deleteMany()
  await db.medication.deleteMany()
  await db.healthMetric.deleteMany()
  await db.article.deleteMany()
  await db.doctor.deleteMany()

  const createdDoctors = await Promise.all(
    doctors.map((d) => db.doctor.create({ data: d }))
  )
  console.log(`✅ Created ${createdDoctors.length} doctors`)

  await Promise.all(
    appointments.map((apt) =>
      db.appointment.create({
        data: { ...apt, doctorId: createdDoctors[0].id },
      })
    )
  )
  console.log(`✅ Created ${appointments.length} appointments`)

  await Promise.all(
    medicalRecords.map((r) => db.medicalRecord.create({ data: r }))
  )
  console.log(`✅ Created ${medicalRecords.length} medical records`)

  await Promise.all(
    medications.map((m) => db.medication.create({ data: m }))
  )
  console.log(`✅ Created ${medications.length} medications`)

  await Promise.all(
    healthMetrics.map((h) => db.healthMetric.create({ data: h }))
  )
  console.log(`✅ Created ${healthMetrics.length} health metrics`)

  await Promise.all(
    articles.map((a) => db.article.create({ data: a }))
  )
  console.log(`✅ Created ${articles.length} articles`)

  console.log('🎉 Seeding complete!')
}

main()
  .catch((e) => {
    console.error('❌ Seed error:', e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })
