#!/bin/bash
# Keep-alive wrapper for the telemedicine service
# Restarts the service if it dies
cd /home/z/my-project/mini-services/telemedicine

while true; do
  echo "[$(date)] Starting telemedicine service..."
  bun index.ts >> /home/z/my-project/telemedicine.log 2>&1
  EXIT_CODE=$?
  echo "[$(date)] Service exited with code $EXIT_CODE. Restarting in 2 seconds..."
  sleep 2
done
