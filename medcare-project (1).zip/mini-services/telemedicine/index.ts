import { createServer } from 'http'
import { Server } from 'socket.io'

const httpServer = createServer()
const io = new Server(httpServer, {
  path: '/',
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
  pingTimeout: 60000,
  pingInterval: 25000,
})

interface TelemedicineUser {
  id: string
  username: string
  role: 'patient' | 'doctor'
  roomId: string
}

interface ChatMessage {
  id: string
  roomId: string
  sender: string
  senderName: string
  content: string
  type: 'user' | 'system'
  timestamp: string
}

// Store users and rooms
const users = new Map<string, TelemedicineUser>()
const rooms = new Map<string, Set<string>>() // roomId -> Set of socket ids

const generateId = () => Math.random().toString(36).substring(2, 11)

const createSystemMessage = (roomId: string, content: string): ChatMessage => ({
  id: generateId(),
  roomId,
  sender: 'system',
  senderName: 'النظام',
  content,
  type: 'system',
  timestamp: new Date().toISOString(),
})

io.on('connection', (socket) => {
  console.log(`[Telemedicine] User connected: ${socket.id}`)

  // Join a telemedicine room
  socket.on('join-room', (data: { username: string; role: 'patient' | 'doctor'; roomId: string }) => {
    const { username, role, roomId } = data

    const user: TelemedicineUser = {
      id: socket.id,
      username,
      role,
      roomId,
    }

    users.set(socket.id, user)
    socket.join(roomId)

    // Add to room tracking
    if (!rooms.has(roomId)) {
      rooms.set(roomId, new Set())
    }
    rooms.get(roomId)!.add(socket.id)

    // Notify room
    const joinMsg = createSystemMessage(roomId, `${username} انضم إلى المكالمة`)
    io.to(roomId).emit('message', joinMsg)

    // Send online users in room
    const roomUsers = Array.from(rooms.get(roomId) || [])
      .map((id) => users.get(id))
      .filter((u): u is TelemedicineUser => !!u)
      .map((u) => ({ id: u.id, username: u.username, role: u.role }))
    io.to(roomId).emit('users-list', { users: roomUsers })

    console.log(`[Telemedicine] ${username} (${role}) joined room ${roomId}. Users in room: ${roomUsers.length}`)
  })

  // Handle chat message
  socket.on('message', (data: { content: string }) => {
    const user = users.get(socket.id)
    if (!user || !data.content?.trim()) return

    const message: ChatMessage = {
      id: generateId(),
      roomId: user.roomId,
      sender: user.id,
      senderName: user.username,
      content: data.content.trim(),
      type: 'user',
      timestamp: new Date().toISOString(),
    }

    // Broadcast to everyone in the room
    io.to(user.roomId).emit('message', message)
    console.log(`[Telemedicine] ${user.username} in ${user.roomId}: ${data.content}`)
  })

  // Handle typing indicator
  socket.on('typing', (data: { isTyping: boolean }) => {
    const user = users.get(socket.id)
    if (!user) return
    socket.to(user.roomId).emit('typing', {
      username: user.username,
      isTyping: data.isTyping,
    })
  })

  // Handle disconnect
  socket.on('disconnect', () => {
    const user = users.get(socket.id)
    if (user) {
      // Remove from room
      const room = rooms.get(user.roomId)
      if (room) {
        room.delete(socket.id)
        if (room.size === 0) {
          rooms.delete(user.roomId)
        }
      }

      users.delete(socket.id)

      // Notify room
      const leaveMsg = createSystemMessage(user.roomId, `${user.username} غادر المكالمة`)
      io.to(user.roomId).emit('message', leaveMsg)

      // Update online users
      const roomUsers = Array.from(rooms.get(user.roomId) || [])
        .map((id) => users.get(id))
        .filter((u): u is TelemedicineUser => !!u)
        .map((u) => ({ id: u.id, username: u.username, role: u.role }))
      io.to(user.roomId).emit('users-list', { users: roomUsers })

      console.log(`[Telemedicine] ${user.username} left room ${user.roomId}`)
    } else {
      console.log(`[Telemedicine] User disconnected: ${socket.id}`)
    }
  })

  socket.on('error', (error) => {
    console.error(`[Telemedicine] Socket error (${socket.id}):`, error)
  })
})

const PORT = 3003
httpServer.listen(PORT, () => {
  console.log(`[Telemedicine] WebSocket server running on port ${PORT}`)
})

process.on('SIGTERM', () => {
  console.log('[Telemedicine] Received SIGTERM, shutting down...')
  httpServer.close(() => process.exit(0))
})

process.on('SIGINT', () => {
  console.log('[Telemedicine] Received SIGINT, shutting down...')
  httpServer.close(() => process.exit(0))
})
